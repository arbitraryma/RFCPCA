
library(TSdist)

# This is a function to compute Fuzzy-C-means with a customized distance

# Input parameters:
# X: dataset whose rows are the observations subject to clustering
# C: number of clusters
# m: fuzziness coefficient
# max_iter: number of iterations
# tol: tolerance with regards to the norm of the difference of memberships matrixes
# dis: considered distance function between the rows of matrix X


fuzzy_c_means <- function(X, C, m = 2, max_iter = 1000, tol = 1e-4, dis = exponential_distance, beta = 0.5) {
  
  
  nrow_x <- nrow(X)
  ncol_x <- ncol(X)
  exponent <- 1/(m-1) 
  
  
  # Computing distance matrix between each pair of rows of X
  
  
  dis_matrix <- matrix(0, nrow = nrow_x, ncol = nrow_x)
  
  
  for (i in 1 : nrow_x) {
    
    for (j in 1 : nrow_x) {
      
      
      dis_matrix[i, j] <- dis(as.numeric(X[i,]), 
                              as.numeric(X[j,]), beta = beta)
      
      
    }
    
  }
  
  
  # Setting iter = 0
  
  iter = 0
  
  # Initializing the membership matrix and the matrix containing the centroids
  
  U <- matrix(0, nrow = nrow_x, ncol = C)
  
  for (i in 1 : nrow_x) {
    
    U[i,] <- rchisq(C, df = 3)
    U[i,] <- U[i,]/sum(U[i,])
    
  }
  
  centroids <- matrix(0, nrow = C, ncol = ncol_x)
  U_old <- U + 1
  
  
  while (iter < max_iter & EuclideanDistance(c(U), c(U_old)) > tol) {
  
  # Updating the centroids 
  
  for (c in 1 : C) {
    
    U_c <- U[,c] # U th column of the membership matrix 
    
      
    centroids[c,] <- apply(U_c^m*X, 2, sum)/(sum(U_c^m))
    
    
    
  }
  
  
  # Updating the membership matrix
  
  U_old <- U
 
  
  for (i in 1 : nrow_x) {
    
    for (c in 1 : C) {
      
      numerator <- dis(as.numeric(X[i,]), as.numeric(centroids[c,]), beta = beta)
      denominator <- numeric()
      
      for (j in 1 : C) {
        
        denominator[j] <- dis(as.numeric(X[i,]), as.numeric(centroids[j,]), beta = beta)
        
      }
      
      U[i, c] <- 1/(sum((numerator/denominator)^exponent))
      
    }
    
  }
  
  
  iter <- iter + 1
  
  
  }
  
  
  return_list <- list('U' = U, 
                      'Centroids' = centroids,
                      'Iter' = iter)
  
  return(return_list)
  
  
}
