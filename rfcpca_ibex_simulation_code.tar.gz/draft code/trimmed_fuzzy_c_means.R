
library(TSdist)

# This is a function to compute Fuzzy-C-means with a customized distance

# Input parameters:
# X: dataset whose rows are the observations subject to clustering
# C: number of clusters
# m: fuzziness coefficient
# max_iter: number of iterations
# tol: tolerance with regards to the norm of the difference of memberships matrixes
# dis: considered distance function between the rows of matrix X


trimmed_fuzzy_c_means <- function(X, C, m = 2, max_iter = 1000, tol = 1e-4, 
                                  dis = EuclideanDistance, alpha = 0.05) {
  
  
  nrow_x <- nrow(X)
  ncol_x <- ncol(X)
  number_trimmed_series <- ceiling(nrow_x * alpha)
  number_non_trimmed_series <- nrow_x - number_trimmed_series
  exponent <- (1)/(m-1)
  exponent_trimmed_1 <- 1/(1 - m)
  exponent_trimmed_2 <- 1 - m
  
  
  # Computing distance matrix between each pair of rows of X
  
  
  dis_matrix <- matrix(0, nrow = nrow_x, ncol = nrow_x)
  
  
  for (i in 1 : nrow_x) {
    
    for (j in 1 : nrow_x) {
      
      
      dis_matrix[i, j] <- dis(as.numeric(X[i,]), 
                              as.numeric(X[j,]))
      
      
    }
    
  }
  
  
  # Setting iter = 0
  
  iter = 0
  
  # Initializing the membership matrix and the matrix containing the centroids
  
  U <- matrix(0, nrow = nrow_x, ncol = C)
  
  for (i in 1 : nrow_x) {
    
    U[i,] <- rchisq(C, df = 3)
    U[i,] <- U[i,]/sum(U[i,])
    
  }
  
  s <- sample(nrow_x, C)
  centroids <- X[s,]
  U_old <- U + 1
  
  
  while (iter < max_iter & EuclideanDistance(c(U), c(U_old)) > tol) {
    
    
    # Identifying the subset of series closest to the centroids 
    
    h <- numeric()
    element <- numeric()
    
    
    for (i in 1 : nrow_x) {
      
      for (c in 1 : C) {
        
        element[c] <- dis(as.numeric(X[i,]), 
                          as.numeric(centroids[c,]))^exponent_trimmed_1
        
        
      }
      
      h[i] <- (sum(element))^(exponent_trimmed_2)
      
    }
    
    
    h_indexes_ascending_order <- order(h) 
    h_remove <- h_indexes_ascending_order[
      -(1 : number_non_trimmed_series)] # Indexes of the observations to be removed
    h_keep <- h_indexes_ascending_order[
      1 : number_non_trimmed_series] # Indexes of the observations to be keep
    
    
    
    # Updating the centroids 
    
    for (c in 1 : C) {
      
      U_c <- U[h_keep, c] # U th column of the membership matrix regarding the
      # non removed observations
      
      
      centroids[c,] <- apply(U_c^m*X[h_keep,], 2, sum)/(sum(U_c^m))
      
      
      
    }
    
    
    # Updating the membership matrix
    
    U_old <- U
    
    
    for (i in 1 : nrow_x) {
      
      for (c in 1 : C) {
        
        numerator <- dis(as.numeric(X[i,]), as.numeric(centroids[c,]))
        denominator <- numeric()
        
        for (j in 1 : C) {
          
          denominator[j] <- dis(as.numeric(X[i,]), as.numeric(centroids[j,]))
          
        }
        
        U[i, c] <- 1/(sum((numerator/denominator)^exponent))
        
      }
      
    }
    
    
    iter <- iter + 1
    
    
  }
  
  
  return_list <- list('U' = U, 
                      'Centroids' = centroids,
                      'Trimmed series' = h_remove)
  
  return(return_list)
  
  
}
