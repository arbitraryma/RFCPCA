

# This is a function to compute the distance regarding the exponential fuzzy C-medoids
# clustering

# Input parameters:
# x: vector
# y: vector
# beta: hyperparameter


exponential_distance <- function(x, y, beta = 0.5) {
  
  sqed <- EuclideanDistance(x, y)^2
  exp_distance <- 1 - exp(-beta*sqed)
  
  return(exp_distance)
  
}
