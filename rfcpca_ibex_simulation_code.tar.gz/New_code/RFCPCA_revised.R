###############################################################################
# RFCPCA ALL-IN-ONE: FCPCA + RFCPCA-E + RFCPCA-N + RFCPCA-T
# FINAL REVIEWED VERSION (2026-09-25)
# Stable, optimized, and faster-converging implementation
# Parallel plan is managed outside RFCPCA functions to avoid stale PSOCK connections.
###############################################################################
# CVI = J / (N_scale * d_min), where d_min is calculated from
# P_s^(l) = C_s^(l) C_s^(l)^T. RFCPCA-N uses the literature noise distance.
###############################################################################

suppressPackageStartupMessages({
  library(stats)
})

.get_parallel_map <- function(parallel = TRUE, seed = TRUE) {
  
  # Set future::plan(...) once outside RFCPCA when parallel execution is desired.
  # This function intentionally does not create or tear down worker clusters.
  if (!parallel) {
    return(function(x, f) lapply(x, f))
  }
  
  if (!requireNamespace("future", quietly = TRUE) ||
      !requireNamespace("furrr", quietly = TRUE)) {
    
    warning(
      "Packages 'future' and/or 'furrr' unavailable; ",
      "using sequential execution."
    )
    
    return(function(x, f) lapply(x, f))
  }
  
  function(x, f) {
    furrr::future_map(
      x,
      f,
      .options = furrr::furrr_options(
        seed = seed
      )
    )
  }
}

.validate_mts_input <- function(ts) {
  if (!is.list(ts) || length(ts) < 2L) {
    stop("ts must be a list containing at least two multivariate time series.")
  }
  
  mats <- lapply(ts, as.matrix)
  p <- ncol(mats[[1L]])
  
  if (is.null(p) || p < 1L) {
    stop("Each MTS must have at least one variable/column.")
  }
  
  nr <- vapply(mats, nrow, integer(1))
  nc <- vapply(mats, ncol, integer(1))
  
  if (any(nr <= 2L)) {
    stop("Every MTS must have at least 3 observations because lag 2 is used.")
  }
  
  if (any(nc != p)) {
    stop("All MTS objects must have the same number of variables/columns.")
  }
  
  finite_ok <- vapply(
    mats,
    function(x) all(is.finite(x)),
    logical(1)
  )
  
  if (!all(finite_ok)) {
    stop(
      "All MTS values must be finite. ",
      "Handle NA/NaN/Inf values before calling RFCPCA."
    )
  }
  
  invisible(TRUE)
}

standardize_mts_fast <- function(mts_data) {
  lapply(mts_data, function(x) {
    x <- as.matrix(x)
    mu <- colMeans(x, na.rm = TRUE)
    sig <- apply(x, 2, sd, na.rm = TRUE)
    sig[!is.finite(sig) | sig == 0] <- 1
    sweep(sweep(x, 2, mu, "-"), 2, sig, "/")
  })
}

cross_covariance_block <- function(x, lag = 1L) {
  x <- as.matrix(x)
  n <- nrow(x)
  if (n <= lag) stop("Time series must have more rows than lag.")
  gamma0 <- stats::cov(x)
  x_t <- x[seq_len(n - lag), , drop = FALSE]
  x_lag <- x[(lag + 1L):n, , drop = FALSE]
  gamma_lag <- stats::cov(x_t, x_lag)
  block <- rbind(cbind(gamma0, gamma_lag), cbind(t(gamma_lag), gamma0))
  combined <- cbind(x_t, x_lag)
  list(block = block, combined = combined, norm2 = sum(combined * combined))
}

prepare_fcpca_data <- function(ts) {
  .validate_mts_input(ts)
  ts <- standardize_mts_fast(ts)
  lag1 <- lapply(ts, cross_covariance_block, lag = 1L)
  lag2 <- lapply(ts, cross_covariance_block, lag = 2L)
  list(
    ts = ts,
    sigma1 = lapply(lag1, `[[`, "block"),
    sigma2 = lapply(lag2, `[[`, "block"),
    combined1 = lapply(lag1, `[[`, "combined"),
    combined2 = lapply(lag2, `[[`, "combined"),
    norm1 = vapply(lag1, `[[`, numeric(1), "norm2"),
    norm2 = vapply(lag2, `[[`, numeric(1), "norm2"),
    length1 = vapply(lag1, function(z) nrow(z$combined), integer(1)),
    length2 = vapply(lag2, function(z) nrow(z$combined), integer(1))
  )
}

weighted_covariances_fast <- function(U, m, sigma1, sigma2) {
  weighted_covariances_from_weights_fast(U^m, sigma1, sigma2)
}

# Weighted CPCA update for robust losses.  For RFCPCA-E the weights are the
# derivative (IRLS) weights u_is^m exp(-beta r_is^2); the common beta factor
# cancels when each cluster covariance is normalized.
weighted_covariances_from_weights_fast <- function(W, sigma1, sigma2) {
  W <- as.matrix(W)
  totals <- colSums(W)
  if (any(!is.finite(totals)) || any(totals <= 1e-12)) {
    stop("At least one cluster has nearly zero total membership weight.")
  }
  d <- nrow(sigma1[[1]])
  flat1 <- vapply(sigma1, as.vector, numeric(d * d))
  flat2 <- vapply(sigma2, as.vector, numeric(d * d))
  cov1 <- flat1 %*% W
  cov2 <- flat2 %*% W
  cov1 <- sweep(cov1, 2, totals, "/")
  cov2 <- sweep(cov2, 2, totals, "/")
  list(
    weighted_cross_cov_lag0_lag1 = lapply(seq_len(ncol(W)), function(j) matrix(cov1[, j], d, d)),
    weighted_cross_cov_lag0_lag2 = lapply(seq_len(ncol(W)), function(j) matrix(cov2[, j], d, d))
  )
}

choose_svd_axes <- function(mat, variance_threshold = 0.95, n_components = NULL) {
  sv <- svd(mat)
  if (is.null(n_components)) {
    denom <- sum(sv$d)
    if (!is.finite(denom) || denom <= 0) {
      n_components <- 1L
    } else {
      n_components <- which(cumsum(sv$d) / denom >= variance_threshold)[1]
      if (is.na(n_components)) n_components <- length(sv$d)
    }
  }
  n_components <- max(1L, min(as.integer(n_components), ncol(sv$u)))
  sv$u[, seq_len(n_components), drop = FALSE]
}

projection_axes_fast <- function(weighted_covariances, variance_threshold = 0.95,
                                 fixed_k1 = NULL, fixed_k2 = NULL) {
  k <- length(weighted_covariances$weighted_cross_cov_lag0_lag1)
  axes <- vector("list", k)
  for (cluster in seq_len(k)) {
    nk1 <- if (is.null(fixed_k1)) NULL else fixed_k1[pmin(cluster, length(fixed_k1))]
    nk2 <- if (is.null(fixed_k2)) NULL else fixed_k2[pmin(cluster, length(fixed_k2))]
    lag01 <- choose_svd_axes(weighted_covariances$weighted_cross_cov_lag0_lag1[[cluster]],
                             variance_threshold = variance_threshold, n_components = nk1)
    lag02 <- choose_svd_axes(weighted_covariances$weighted_cross_cov_lag0_lag2[[cluster]],
                             variance_threshold = variance_threshold, n_components = nk2)
    axes[[cluster]] <- list(lag01 = lag01, lag02 = lag02, k1 = ncol(lag01), k2 = ncol(lag02))
  }
  axes
}

# Reconstruction errors are comparable only when all clusters have the same
# subspace dimension. Select that common dimension from the pooled spectrum,
# independently of cluster labels and initialization.
global_component_counts <- function(prep, variance_threshold = 0.95) {
  avg1 <- Reduce(`+`, prep$sigma1) / length(prep$sigma1)
  avg2 <- Reduce(`+`, prep$sigma2) / length(prep$sigma2)
  c(k1 = ncol(choose_svd_axes(avg1, variance_threshold)),
    k2 = ncol(choose_svd_axes(avg2, variance_threshold)))
}

# Robust common ranks: determine the variance-threshold rank independently for
# each series, then aggregate the integer ranks by their median.  This is
# label-free and remains well-defined for unequal series lengths because the
# prepared lag cross-covariance matrices all have the same channel dimension.
robust_global_component_counts <- function(prep, variance_threshold = 0.95) {
  validate_lag_list <- function(x, name) {
    if (!is.list(x) || !length(x)) stop(name, " must be a non-empty list.")
    dims <- vapply(x, function(z) paste(dim(as.matrix(z)), collapse = "x"), character(1))
    if (length(unique(dims)) != 1L) stop(name, " matrices must have common dimensions.")
  }
  per_series_rank <- function(x) vapply(x, function(z) {
    d <- svd(as.matrix(z), nu = 0, nv = 0)$d
    total <- sum(d)
    q <- if (!is.finite(total) || total <= 0) 1L else
      which(cumsum(d) / total >= variance_threshold)[1L]
    as.integer(max(1L, min(q, length(d))))
  }, integer(1))
  validate_lag_list(prep$sigma1, "prep$sigma1")
  validate_lag_list(prep$sigma2, "prep$sigma2")
  r1 <- per_series_rank(prep$sigma1)
  r2 <- per_series_rank(prep$sigma2)
  max1 <- min(dim(as.matrix(prep$sigma1[[1L]])))
  max2 <- min(dim(as.matrix(prep$sigma2[[1L]])))
  out <- c(k1 = as.integer(max(1L, min(round(stats::median(r1)), max1))),
           k2 = as.integer(max(1L, min(round(stats::median(r2)), max2))))
  attr(out, "per_series_rank_lag1") <- r1
  attr(out, "per_series_rank_lag2") <- r2
  attr(out, "rank_rule") <- "median_series"
  out
}

select_global_component_counts <- function(prep, variance_threshold = 0.95,
                                           rank_rule = c("median_series", "pooled_mean")) {
  rank_rule <- match.arg(rank_rule)
  if (rank_rule == "median_series") {
    robust_global_component_counts(prep, variance_threshold)
  } else {
    out <- global_component_counts(prep, variance_threshold)
    attr(out, "per_series_rank_lag1") <- NULL
    attr(out, "per_series_rank_lag2") <- NULL
    attr(out, "rank_rule") <- "pooled_mean"
    out
  }
}

reconstruction_error_fast <- function(prep, projection_axes, normalize_by_length = TRUE) {
  n <- length(prep$combined1)
  k <- length(projection_axes)
  err <- matrix(0, nrow = n, ncol = k)
  for (cluster in seq_len(k)) {
    C1 <- projection_axes[[cluster]]$lag01
    C2 <- projection_axes[[cluster]]$lag02
    err1 <- vapply(seq_len(n), function(i) {
      z <- prep$combined1[[i]] %*% C1
      value <- max(prep$norm1[i] - sum(z * z), 0)
      if (normalize_by_length) value / prep$length1[i] else value
    }, numeric(1))
    err2 <- vapply(seq_len(n), function(i) {
      z <- prep$combined2[[i]] %*% C2
      value <- max(prep$norm2[i] - sum(z * z), 0)
      if (normalize_by_length) value / prep$length2[i] else value
    }, numeric(1))
    err[, cluster] <- err1 + err2
  }
  err
}

update_membership_fast <- function(distance, m, eps = 1e-12) {
  if (!is.finite(m) || m <= 1) stop("m must be finite and greater than 1.")
  distance <- as.matrix(distance)
  if (any(!is.finite(distance)) || any(distance < 0)) {
    stop("Distances must be finite and non-negative.")
  }
  n <- nrow(distance); k <- ncol(distance)
  U <- matrix(0, nrow = n, ncol = k)
  zero_rows <- apply(distance <= eps, 1, any)
  if (any(zero_rows)) {
    for (i in which(zero_rows)) {
      z <- which(distance[i, ] <= eps)
      U[i, z] <- 1 / length(z)
    }
  }
  regular <- !zero_rows
  if (any(regular)) {
    D <- pmax(distance[regular, , drop = FALSE], eps)
    # Log-domain evaluation prevents overflow/underflow when m is close to 1.
    log_weight <- -log(D) / (m - 1)
    log_weight <- sweep(log_weight, 1, apply(log_weight, 1, max), "-")
    weight <- exp(log_weight)
    U[regular, ] <- weight / rowSums(weight)
  }
  U
}

damp_and_normalize <- function(U_old, U_raw, damping = 0.8) {
  U_new <- damping * U_raw + (1 - damping) * U_old
  rs <- rowSums(U_new)
  rs[!is.finite(rs) | rs <= 0] <- 1
  U_new / rs
}

random_membership <- function(n, k, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  U <- matrix(stats::runif(n * k), nrow = n, ncol = k)
  U / rowSums(U)
}

structured_random_membership <- function(n, k, confidence = 0.90, seed = NULL) {
  if (k < 2L || k >= n) stop("k must be between 2 and n - 1.")
  if (!is.finite(confidence) || confidence <= 1 / k || confidence >= 1) {
    stop("confidence must be strictly between 1/k and 1.")
  }
  
  if (!is.null(seed)) set.seed(seed)
  
  lab <- rep(seq_len(k), length.out = n)
  lab <- sample(lab, size = n, replace = FALSE)
  
  low <- (1 - confidence) / (k - 1)
  U <- matrix(low, nrow = n, ncol = k)
  for (i in seq_len(n)) U[i, lab[i]] <- confidence
  U <- U / rowSums(U)
  
  attr(U, "initial_labels") <- lab
  attr(U, "cluster_sizes") <- table(factor(lab, levels = seq_len(k)))
  attr(U, "initializer_algorithm") <- "structured_random"
  U
}

.validate_startU <- function(startU, n, k) {
  U <- as.matrix(startU)
  
  if (!all(dim(U) == c(n, k))) {
    stop(sprintf(
      "startU must have dimension %d x %d; got %d x %d.",
      n, k, nrow(U), ncol(U)
    ))
  }
  
  if (any(!is.finite(U)) || any(U < 0)) {
    stop("startU must contain finite non-negative values.")
  }
  
  rs <- rowSums(U)
  if (any(!is.finite(rs)) || any(rs <= 0)) {
    stop("Every row of startU must have positive total membership.")
  }
  
  U / rs
}

.grid_seed <- function(seed, idx) {
  if (isFALSE(seed) || is.null(seed)) return(NULL)
  if (isTRUE(seed)) return(as.integer(idx))
  if (is.numeric(seed) && length(seed) == 1L && is.finite(seed)) {
    return(as.integer(seed) + as.integer(idx) - 1L)
  }
  stop("seed must be TRUE, FALSE, NULL, or one finite numeric value.")
}

# Robust, label-free initialization from lag-covariance features.
#
# This version deliberately avoids prcomp() on the very wide N x P matrix
# and avoids PAM object extraction.  It uses dual PCA through the N x N
# Gram matrix G = Z Z^T, so the score matrix always has exactly N rows.
robust_membership_init <- function(prep, k, m = 1.5, seed = NULL,
                                   winsor = 3, max_pc = 10L,
                                   confidence = 0.90) {
  n <- length(prep$sigma1)
  
  if (k < 2L || k >= n) {
    stop("k must be between 2 and n - 1 for robust initialization.")
  }
  if (!is.finite(confidence) || confidence <= 1 / k || confidence >= 1) {
    stop("confidence must be strictly between 1/k and 1.")
  }
  if (!is.finite(winsor) || winsor <= 0) {
    stop("winsor must be positive.")
  }
  if (!is.finite(max_pc) || max_pc < 1) {
    stop("max_pc must be at least 1.")
  }
  
  upper_vec <- function(S) {
    S <- as.matrix(S)
    S[upper.tri(S, diag = TRUE)]
  }
  
  v1 <- lapply(prep$sigma1, upper_vec)
  v2 <- lapply(prep$sigma2, upper_vec)
  
  p1 <- length(v1[[1L]])
  p2 <- length(v2[[1L]])
  
  if (any(vapply(v1, length, integer(1)) != p1) ||
      any(vapply(v2, length, integer(1)) != p2)) {
    stop("Lag-covariance matrices do not have consistent dimensions.")
  }
  
  F1 <- matrix(
    unlist(v1, use.names = FALSE),
    nrow = n, ncol = p1, byrow = TRUE
  )
  F2 <- matrix(
    unlist(v2, use.names = FALSE),
    nrow = n, ncol = p2, byrow = TRUE
  )
  F <- cbind(F1, F2)
  F <- as.matrix(F)
  storage.mode(F) <- "double"
  
  if (!is.matrix(F) || nrow(F) != n || ncol(F) != (p1 + p2)) {
    stop(sprintf(
      "Could not construct the expected N x P feature matrix: got %d x %d; expected %d x %d.",
      nrow(F), ncol(F), n, p1 + p2
    ))
  }
  if (any(!is.finite(F))) {
    stop("Lag-covariance feature matrix contains non-finite values.")
  }
  
  med <- apply(F, 2, stats::median, na.rm = TRUE)
  sc <- apply(F, 2, stats::mad, constant = 1.4826, na.rm = TRUE)
  keep <- is.finite(sc) & sc > 1e-10
  
  if (!any(keep)) {
    warning(
      "No informative lag-covariance features were found; ",
      "using structured random initialization."
    )
    return(structured_random_membership(
      n = n, k = k, confidence = confidence, seed = seed
    ))
  }
  
  Z <- sweep(F[, keep, drop = FALSE], 2, med[keep], "-")
  Z <- sweep(Z, 2, sc[keep], "/")
  Z[!is.finite(Z)] <- 0
  
  # Preserve matrix dimensions during winsorization.
  # Using pmin/pmax with a scalar first argument can drop dim attributes in R.
  if (!is.matrix(Z)) {
    Z <- matrix(Z, nrow = n, ncol = sum(keep))
  }
  Z[Z > winsor] <- winsor
  Z[Z < -winsor] <- -winsor
  
  if (!is.matrix(Z) || nrow(Z) != n || ncol(Z) != sum(keep)) {
    stop(sprintf(
      "Internal initializer error after winsorization: Z is %d x %d; expected %d x %d.",
      if (is.null(dim(Z))) length(Z) else nrow(Z),
      if (is.null(dim(Z))) 1L else ncol(Z),
      n, sum(keep)
    ))
  }
  
  Zc <- sweep(Z, 2, colMeans(Z), "-")
  
  if (!is.matrix(Zc) || nrow(Zc) != n || ncol(Zc) != ncol(Z)) {
    stop("Internal initializer error: centered feature matrix lost its dimensions.")
  }
  
  G <- tcrossprod(Zc)
  G <- (G + t(G)) / 2
  
  if (!all(dim(G) == c(n, n)) || any(!is.finite(G))) {
    stop("Dual-PCA Gram matrix has invalid dimensions or non-finite entries.")
  }
  
  eig <- eigen(G, symmetric = TRUE)
  eigval <- pmax(as.numeric(eig$values), 0)
  
  tol <- max(eigval, 0) * 1e-10
  positive <- which(eigval > max(tol, .Machine$double.eps))
  
  if (length(positive) < 1L) {
    warning(
      "Lag-covariance features contain no usable PCA variation; ",
      "using structured random initialization."
    )
    return(structured_random_membership(
      n = n, k = k, confidence = confidence, seed = seed
    ))
  }
  
  q_use <- min(
    as.integer(max_pc),
    n - 1L,
    length(positive)
  )
  
  ids <- positive[seq_len(q_use)]
  
  scores <- sweep(
    eig$vectors[, ids, drop = FALSE],
    2,
    sqrt(eigval[ids]),
    "*"
  )
  scores <- as.matrix(scores)
  storage.mode(scores) <- "double"
  
  if (!all(dim(scores) == c(n, q_use))) {
    stop(sprintf(
      "Internal initializer error: score matrix is %d x %d; expected %d x %d.",
      nrow(scores), ncol(scores), n, q_use
    ))
  }
  
  score_sd <- apply(scores, 2, stats::sd)
  good_sd <- is.finite(score_sd) & score_sd > 1e-12
  if (any(good_sd)) {
    scores[, good_sd] <- sweep(
      scores[, good_sd, drop = FALSE],
      2, score_sd[good_sd], "/"
    )
  }
  
  if (!is.null(seed)) set.seed(seed)
  
  if (!is.matrix(scores) || nrow(scores) != n || ncol(scores) < 1L) {
    stop("Internal initializer error: invalid score matrix before k-means.")
  }
  
  km <- tryCatch(
    stats::kmeans(
      x = scores,
      centers = k,
      nstart = 50,
      iter.max = 100,
      algorithm = "Hartigan-Wong"
    ),
    error = function(e) NULL
  )
  
  if (is.null(km) || is.null(km$cluster) || length(km$cluster) != n) {
    warning(
      "k-means initialization failed; using structured random initialization."
    )
    return(structured_random_membership(
      n = n, k = k, confidence = confidence, seed = seed
    ))
  }
  
  lab <- as.integer(km$cluster)
  
  if (anyNA(lab) ||
      any(!(lab %in% seq_len(k))) ||
      length(unique(lab)) < k) {
    warning(
      "k-means returned an invalid preliminary partition; ",
      "using structured random initialization."
    )
    return(structured_random_membership(
      n = n, k = k, confidence = confidence, seed = seed
    ))
  }
  
  low <- (1 - confidence) / (k - 1)
  U <- matrix(low, nrow = n, ncol = k)
  for (i in seq_len(n)) {
    U[i, lab[i]] <- confidence
  }
  U <- U / rowSums(U)
  
  if (max(abs(rowSums(U) - 1)) > 1e-10) {
    stop("Robust initializer produced rows that do not sum to one.")
  }
  if (max(abs(apply(U, 1, max) - confidence)) > 1e-8) {
    stop("Robust initializer failed to impose the requested confidence.")
  }
  if (k == 2L && all(abs(U[, 1] - U[, 2]) < 1e-12)) {
    stop("Robust initializer collapsed to the symmetric (0.5, 0.5) solution.")
  }
  
  attr(U, "initial_labels") <- lab
  attr(U, "cluster_sizes") <- table(factor(lab, levels = seq_len(k)))
  attr(U, "features_retained") <- sum(keep)
  attr(U, "feature_matrix_dim") <- dim(F)
  attr(U, "scaled_feature_matrix_dim") <- dim(Z)
  attr(U, "pca_components_used") <- q_use
  attr(U, "score_matrix_dim") <- dim(scores)
  attr(U, "initializer_algorithm") <- "robust_dual_pca_kmeans"
  
  U
}

initial_state_fast <- function(prep, k, m, startU = NULL, seed = NULL,
                               variance_threshold = 0.95,
                               fix_components = TRUE,
                               rank_rule = c("median_series", "pooled_mean"),
                               init_method = c("robust_lag", "fcpca", "random"),
                               init_confidence = 0.90) {
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  n <- length(prep$ts)
  
  if (!is.null(startU)) {
    U <- .validate_startU(startU, n = n, k = k)
    initialization <- "user"
  } else if (init_method == "fcpca") {
    old <- fcpca_fast(
      ts = prep$ts,
      k = k,
      m = m,
      prep = prep,
      verbose = FALSE,
      replicates = 1,
      variance_threshold = variance_threshold,
      seed = seed,
      fix_components = fix_components,
      rank_rule = rank_rule,
      init_method = "random"
    )
    old$initialization <- "fcpca"
    return(old)
  } else if (init_method == "robust_lag") {
    U <- robust_membership_init(
      prep = prep,
      k = k,
      m = m,
      seed = seed,
      confidence = init_confidence
    )
    initialization <- "robust_lag"
  } else {
    U <- random_membership(n, k, seed)
    initialization <- "random"
  }
  
  wc <- weighted_covariances_fast(U, m, prep$sigma1, prep$sigma2)
  
  if (isTRUE(fix_components)) {
    common_rank <- select_global_component_counts(prep, variance_threshold, rank_rule)
    fixed_k1 <- unname(common_rank["k1"])
    fixed_k2 <- unname(common_rank["k2"])
    per_rank1 <- attr(common_rank, "per_series_rank_lag1")
    per_rank2 <- attr(common_rank, "per_series_rank_lag2")
    axes <- projection_axes_fast(
      wc,
      variance_threshold = variance_threshold,
      fixed_k1 = fixed_k1,
      fixed_k2 = fixed_k2
    )
  } else {
    fixed_k1 <- NULL
    fixed_k2 <- NULL
    per_rank1 <- NULL
    per_rank2 <- NULL
    axes <- projection_axes_fast(
      wc,
      variance_threshold = variance_threshold
    )
  }
  
  list(
    membership_matrix = U,
    projection_axes = axes,
    reconstruction_error_matrix = reconstruction_error_fast(prep, axes),
    n_components_lag01 = fixed_k1,
    n_components_lag02 = fixed_k2,
    rank_rule = rank_rule,
    per_series_rank_lag1 = per_rank1,
    per_series_rank_lag2 = per_rank2,
    initialization = initialization,
    initial_cluster_sizes = attr(U, "cluster_sizes"),
    initial_features_retained = attr(U, "features_retained"),
    initial_pca_components = attr(U, "pca_components_used"),
    initial_algorithm = attr(U, "initializer_algorithm"),
    fix_components = isTRUE(fix_components)
  )
}

relative_change <- function(old, new) {
  if (!is.finite(old)) return(Inf)
  abs(old - new) / (abs(old) + 1e-8)
}

compute_projection_dmin_fast <- function(projection_axes) {
  k <- length(projection_axes)
  if (k < 2L) return(NA_real_)
  projection_distance <- function(a, b) {
    C_a1 <- projection_axes[[a]]$lag01; C_b1 <- projection_axes[[b]]$lag01
    C_a2 <- projection_axes[[a]]$lag02; C_b2 <- projection_axes[[b]]$lag02
    P_a1 <- C_a1 %*% t(C_a1); P_b1 <- C_b1 %*% t(C_b1)
    P_a2 <- C_a2 %*% t(C_a2); P_b2 <- C_b2 %*% t(C_b2)
    sum((P_a1 - P_b1)^2) + sum((P_a2 - P_b2)^2)
  }
  distances <- numeric(0)
  for (a in seq_len(k - 1L)) for (b in (a + 1L):k) {
    distances <- c(distances, projection_distance(a, b))
  }
  min(distances)
}

compute_original_CVI_fast <- function(objective, projection_axes, n_scale) {
  d_min <- compute_projection_dmin_fast(projection_axes)
  if (!is.finite(objective) || !is.finite(n_scale) || n_scale <= 0 ||
      !is.finite(d_min) || d_min <= .Machine$double.eps) return(Inf)
  objective / (n_scale * d_min)
}

fcpca_fast <- function(ts, k, m = 1.5, startU = NULL, prep = NULL,
                       conver = 1e-4, rel_conver = 1e-5, maxit = 150,
                       verbose = TRUE, replicates = 1, variance_threshold = 0.95,
                       seed = NULL, damping = 0.8, fix_components = TRUE,
                       rank_rule = c("median_series", "pooled_mean"),
                       init_method = c("random", "robust_lag"),
                       init_confidence = 0.90) {
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  
  if (!is.finite(m) || m <= 1) stop("m must be finite and > 1.")
  if (!is.finite(damping) || damping <= 0 || damping > 1) {
    stop("damping must be in (0, 1].")
  }
  if (!is.finite(replicates) || replicates < 1) {
    stop("replicates must be at least 1.")
  }
  
  if (is.null(prep)) prep <- prepare_fcpca_data(ts)
  n <- length(prep$ts)
  
  if (k < 2L || k >= n) stop("k must be between 2 and n - 1.")
  
  if (isTRUE(fix_components)) {
    common_rank <- select_global_component_counts(prep, variance_threshold, rank_rule)
    fixed_k1 <- unname(common_rank["k1"])
    fixed_k2 <- unname(common_rank["k2"])
    per_rank1 <- attr(common_rank, "per_series_rank_lag1")
    per_rank2 <- attr(common_rank, "per_series_rank_lag2")
  } else {
    fixed_k1 <- NULL
    fixed_k2 <- NULL
    per_rank1 <- NULL
    per_rank2 <- NULL
  }
  
  best_result <- NULL
  best_error <- Inf
  
  for (replicate_i in seq_len(as.integer(replicates))) {
    rep_seed <- if (is.null(seed)) NULL else as.integer(seed) + replicate_i - 1L
    
    if (verbose) cat(sprintf("\nReplicate %d:\n", replicate_i))
    
    if (!is.null(startU)) {
      U <- .validate_startU(startU, n = n, k = k)
      init_used <- "user"
    } else if (init_method == "robust_lag") {
      U <- robust_membership_init(
        prep = prep,
        k = k,
        m = m,
        seed = rep_seed,
        confidence = init_confidence
      )
      init_used <- "robust_lag"
    } else {
      U <- random_membership(n, k, rep_seed)
      init_used <- "random"
    }
    
    iteration <- 0L
    current_error <- Inf
    prev_error <- Inf
    rel_obj_change <- Inf
    converged <- FALSE
    axes <- NULL
    rec_error <- NULL
    
    repeat {
      iteration <- iteration + 1L
      
      weighted_cov <- weighted_covariances_fast(
        U, m, prep$sigma1, prep$sigma2
      )
      
      axes <- projection_axes_fast(
        weighted_cov,
        variance_threshold = variance_threshold,
        fixed_k1 = fixed_k1,
        fixed_k2 = fixed_k2
      )
      
      rec_error <- reconstruction_error_fast(prep, axes)
      U_raw <- update_membership_fast(rec_error, m)
      U_new <- damp_and_normalize(U, U_raw, damping = damping)
      
      diffU <- max(abs(U - U_new))
      prev_error <- current_error
      U <- U_new
      current_error <- sum((U^m) * rec_error)
      rel_obj_change <- relative_change(prev_error, current_error)
      
      if (verbose) {
        cat(sprintf(
          "Iteration %d: Obj = %.6f, dU = %.6g, relObj = %.6g, k1 = %d, k2 = %d\n",
          iteration, current_error, diffU, rel_obj_change,
          axes[[1]]$k1, axes[[1]]$k2
        ))
      }
      
      if (iteration >= 5L &&
          diffU <= conver &&
          rel_obj_change <= rel_conver) {
        converged <- TRUE
        break
      }
      
      if (iteration >= maxit) break
    }
    
    final_weighted_cov <- weighted_covariances_fast(
      U, m, prep$sigma1, prep$sigma2
    )
    axes <- projection_axes_fast(
      final_weighted_cov,
      variance_threshold = variance_threshold,
      fixed_k1 = fixed_k1,
      fixed_k2 = fixed_k2
    )
    rec_error <- reconstruction_error_fast(prep, axes)
    current_error <- sum((U^m) * rec_error)
    
    if (is.finite(current_error) && current_error < best_error) {
      best_error <- current_error
      best_result <- list(
        method = "FCPCA",
        membership_matrix = U,
        projection_axes = axes,
        iterations = iteration,
        converged = converged,
        reconstruction_error = current_error,
        reconstruction_error_matrix = rec_error,
        hard_cluster = max.col(U, ties.method = "first"),
        weighted_covariances = final_weighted_cov,
        S_value = compute_original_CVI_fast(current_error, axes, n),
        CVI = compute_original_CVI_fast(current_error, axes, n),
        n_components_lag01 = fixed_k1,
        n_components_lag02 = fixed_k2,
        rank_rule = rank_rule,
        per_series_rank_lag1 = per_rank1,
        per_series_rank_lag2 = per_rank2,
        sigma = prep$sigma1,
        sigma2 = prep$sigma2,
        combined_list = prep$combined1,
        combined_list2 = prep$combined2,
        norm1 = prep$norm1,
        norm2 = prep$norm2,
        prep = prep,
        k = k,
        m = m,
        damping = damping,
        conver = conver,
        rel_conver = rel_conver,
        initialization = init_used,
        fix_components = isTRUE(fix_components)
      )
    }
  }
  
  if (is.null(best_result)) stop("FCPCA failed to produce a finite solution.")
  best_result
}

rfcpca_e_fast_once <- function(ts, k, m, startU = NULL, prep = NULL,
                               conver = 1e-4, rel_conver = 1e-5, maxit = 150,
                               verbose = TRUE, variance_threshold = 0.95, seed = NULL,
                               damping = 0.8, fix_components = TRUE, beta_scale = NULL,
                               rank_rule = c("median_series", "pooled_mean"),
                               beta_tail_weight = 0.80, beta_fence_k = 2.5,
                               beta_rule = c("paper_mean", "robust_fence"),
                               init_method = c("robust_lag", "fcpca", "random"),
                               init_confidence = 0.90) {
  beta_rule <- match.arg(beta_rule)
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  
  if (is.null(prep)) prep <- prepare_fcpca_data(ts)
  
  initial <- initial_state_fast(
    prep = prep,
    k = k,
    m = m,
    startU = startU,
    seed = seed,
    variance_threshold = variance_threshold,
    fix_components = fix_components,
    rank_rule = rank_rule,
    init_method = init_method,
    init_confidence = init_confidence
  )
  
  U <- initial$membership_matrix
  rec_error <- initial$reconstruction_error_matrix
  min_err0 <- apply(rec_error, 1, min)
  
  robust_fence <- stats::median(min_err0) +
    beta_fence_k * stats::mad(min_err0, constant = 1.4826)
  
  if (!is.finite(robust_fence) || robust_fence <= 0) {
    robust_fence <- as.numeric(stats::quantile(min_err0, .90, na.rm = TRUE))
  }
  
  if (is.null(beta_scale)) {
    beta <- if (beta_rule == "paper_mean") {
      1 / max(mean(min_err0), 1e-8)
    } else {
      -log(beta_tail_weight) / max(robust_fence, 1e-8)
    }
    beta_scale_used <- NA_real_
  } else {
    beta <- beta_scale / (stats::median(min_err0) + 1e-8)
    beta_scale_used <- beta_scale
  }
  
  if (!is.finite(beta) || beta <= 0) {
    stop("RFCPCA-E produced an invalid beta.")
  }
  
  fixed_k1 <- if (isTRUE(fix_components)) initial$n_components_lag01 else NULL
  fixed_k2 <- if (isTRUE(fix_components)) initial$n_components_lag02 else NULL
  
  iteration <- 0L
  objective <- Inf
  prev_obj <- Inf
  rel_obj_change <- Inf
  axes <- initial$projection_axes
  converged <- FALSE
  
  repeat {
    iteration <- iteration + 1L
    
    D <- pmax(-expm1(-beta * rec_error), .Machine$double.eps)
    U_raw <- update_membership_fast(D, m)
    U_new <- damp_and_normalize(U, U_raw, damping)
    diffU <- max(abs(U - U_new))
    U <- U_new
    
    influence <- exp(-beta * rec_error)
    weighted_cov <- weighted_covariances_from_weights_fast(
      (U^m) * influence,
      prep$sigma1,
      prep$sigma2
    )
    
    axes <- projection_axes_fast(
      weighted_cov,
      variance_threshold = variance_threshold,
      fixed_k1 = fixed_k1,
      fixed_k2 = fixed_k2
    )
    
    rec_error_new <- reconstruction_error_fast(prep, axes)
    D_new <- pmax(-expm1(-beta * rec_error_new), .Machine$double.eps)
    
    prev_obj <- objective
    objective <- sum((U^m) * D_new)
    rel_obj_change <- relative_change(prev_obj, objective)
    rec_error <- rec_error_new
    
    if (verbose) {
      cat(sprintf(
        "Iteration %d (RFCPCA-E): J_exp = %.6f, dU = %.6g, relObj = %.6g\n",
        iteration, objective, diffU, rel_obj_change
      ))
    }
    
    if (iteration >= 5L &&
        diffU <= conver &&
        rel_obj_change <= rel_conver) {
      converged <- TRUE
      break
    }
    
    if (iteration >= maxit) break
  }
  
  final_influence <- exp(-beta * rec_error)
  final_weighted_cov <- weighted_covariances_from_weights_fast(
    (U^m) * final_influence,
    prep$sigma1,
    prep$sigma2
  )
  axes <- projection_axes_fast(
    final_weighted_cov,
    variance_threshold = variance_threshold,
    fixed_k1 = fixed_k1,
    fixed_k2 = fixed_k2
  )
  rec_error <- reconstruction_error_fast(prep, axes)
  final_influence <- exp(-beta * rec_error)
  
  D_final <- pmax(-expm1(-beta * rec_error), .Machine$double.eps)
  objective <- sum((U^m) * D_final)
  
  cluster_ess <- vapply(seq_len(k), function(s) {
    w <- (U[, s]^m) * final_influence[, s]
    sum(w)^2 / max(sum(w^2), .Machine$double.eps)
  }, numeric(1))
  
  effective_fraction <- mean(cluster_ess) / nrow(U)
  
  list(
    method = "RFCPCA-E",
    membership_matrix = U,
    projection_axes = axes,
    reconstruction_error_matrix = rec_error,
    weighted_covariances = final_weighted_cov,
    beta = beta,
    objective = objective,
    S_value = compute_original_CVI_fast(objective, axes, nrow(U)),
    CVI = compute_original_CVI_fast(objective, axes, nrow(U)),
    hard_cluster = max.col(U, ties.method = "first"),
    iterations = iteration,
    converged = converged,
    k = k,
    m = m,
    optimal_k = k,
    optimal_m = m,
    damping = damping,
    influence_weights = final_influence,
    effective_fraction = effective_fraction,
    beta_scale = beta_scale_used,
    beta_rule = if (is.null(beta_scale)) beta_rule else "scale_grid",
    beta_tail_weight = beta_tail_weight,
    beta_fence = robust_fence,
    initialization = initial$initialization,
    initial_cluster_sizes = initial$initial_cluster_sizes,
    initial_features_retained = initial$initial_features_retained,
    initial_pca_components = initial$initial_pca_components,
    initial_algorithm = initial$initial_algorithm,
    rank_rule = initial$rank_rule,
    n_components_lag01 = initial$n_components_lag01,
    n_components_lag02 = initial$n_components_lag02,
    per_series_rank_lag1 = initial$per_series_rank_lag1,
    per_series_rank_lag2 = initial$per_series_rank_lag2,
    fix_components = isTRUE(fix_components),
    conver = conver,
    rel_conver = rel_conver
  )
}

find_optimal_delta_fast <- function(rec_err_mat, jump_threshold = 0.15, verbose = FALSE, lambda_min = 1e-4) {
  mean_vec <- colMeans(rec_err_mat)
  centered <- sweep(rec_err_mat, 2, mean_vec)
  delta_M <- sqrt(mean(rowSums(centered^2)))
  if (!is.finite(delta_M) || delta_M <= 0) delta_M <- sqrt(mean(apply(rec_err_mat, 1, min))) + 1e-8
  lambda <- 1; lambda_vec <- numeric(0); p_vec <- numeric(0); min_d2 <- apply(rec_err_mat, 1, min)
  repeat {
    delta <- lambda * delta_M
    p <- mean(min_d2 > delta^2)
    lambda_vec <- c(lambda_vec, lambda); p_vec <- c(p_vec, p)
    if (verbose) cat(sprintf("lambda = %.5f | p = %.3f\n", lambda, p))
    if (p > 0.5 || lambda < lambda_min) break
    lambda <- lambda / 2
  }
  trace <- data.frame(lambda = lambda_vec, p = p_vec)
  diffs <- diff(trace$p); jump_idx <- which(diffs > jump_threshold)[1]
  lambda_opt <- if (!is.na(jump_idx) && jump_idx > 1) trace$lambda[jump_idx] else min(trace$lambda)
  list(lambda_opt = lambda_opt, delta_opt = lambda_opt * delta_M, delta_M = delta_M, trace = trace)
}

# Literature noise-cluster scale rule
#
#   delta^2 = lambda / {n (C - 1)} * sum_i sum_c d_ic^2.
#
# rec_err_mat contains the squared distances to the regular clusters only, so
# ncol(rec_err_mat) is C - 1.  No centering or additional squaring is required.
find_optimal_delta_literature_fast <- function(
    rec_err_mat,
    m = 1.5,
    jump_threshold = 0.15,
    verbose = FALSE,
    lambda_min = 1e-4,
    lambda_start = 1,
    lambda_max = 16,
    target_noise_upper = 0.05,
    grid_ratio = sqrt(2)
) {
  
  # ------------------------------------------------------------
  # 1. Input checks
  # ------------------------------------------------------------
  
  rec_err_mat <- as.matrix(rec_err_mat)
  
  n <- nrow(rec_err_mat)
  k <- ncol(rec_err_mat)   # number of REGULAR clusters
  
  if (n < 2L || k < 1L) {
    stop("The noise-cluster rule requires n >= 2 and at least one regular cluster.")
  }
  
  if (!is.finite(m) || m <= 1) {
    stop("m must be finite and greater than 1.")
  }
  
  if (!is.finite(jump_threshold) ||
      jump_threshold < 0 ||
      jump_threshold > 1) {
    stop("jump_threshold must be between 0 and 1.")
  }
  
  if (!is.finite(lambda_min) || lambda_min <= 0) {
    stop("lambda_min must be positive.")
  }
  
  if (!is.finite(lambda_start) || lambda_start <= 0) {
    stop("lambda_start must be positive.")
  }
  
  if (!is.finite(lambda_max) || lambda_max < lambda_start) {
    stop("lambda_max must be >= lambda_start.")
  }
  
  if (!is.finite(target_noise_upper) ||
      target_noise_upper < 0 ||
      target_noise_upper >= 1) {
    stop("target_noise_upper must be in [0, 1).")
  }
  
  if (!is.finite(grid_ratio) || grid_ratio <= 1) {
    stop("grid_ratio must be greater than 1.")
  }
  
  if (any(!is.finite(rec_err_mat)) ||
      any(rec_err_mat < 0)) {
    stop("Reconstruction errors must be finite and non-negative.")
  }
  
  
  # ------------------------------------------------------------
  # 2. Global reconstruction-error scale
  #
  # delta^2(lambda)
  #   = lambda / (N*S) * sum_i sum_s r_is^2
  #   = lambda * mean(r_is^2)
  #
  # Here k = S = number of regular clusters.
  # ------------------------------------------------------------
  
  base_scale_sq <- mean(rec_err_mat)
  
  base_scale_sq <- max(
    base_scale_sq,
    .Machine$double.eps
  )
  
  
  # ------------------------------------------------------------
  # 3. Evaluate one lambda value
  # ------------------------------------------------------------
  
  evaluate_lambda <- function(lambda) {
    
    delta_sq <- lambda * base_scale_sq
    
    memberships <- noise_membership_update_fast(
      rec_err_mat,
      delta_sq,
      m
    )
    
    # Last column = noise-cluster membership
    noise <- memberships[, k + 1L]
    
    # Largest membership among regular clusters
    valid_max <- apply(
      memberships[, seq_len(k), drop = FALSE],
      1,
      max
    )
    
    c(
      delta_sq = delta_sq,
      
      noise_proportion =
        mean(noise >= valid_max),
      
      mean_noise_membership =
        mean(noise)
    )
  }
  
  
  # ------------------------------------------------------------
  # 4. Adaptively determine the upper lambda
  #
  # Start from lambda = 1.
  # If too many observations are already classified as noise,
  # increase lambda until the noise proportion is sufficiently low.
  # ------------------------------------------------------------
  
  lambda_upper <- lambda_start
  
  upper_eval <- evaluate_lambda(lambda_upper)
  
  while (
    upper_eval["noise_proportion"] > target_noise_upper &&
    lambda_upper < lambda_max
  ) {
    
    lambda_upper <- min(
      lambda_upper * 2,
      lambda_max
    )
    
    upper_eval <- evaluate_lambda(lambda_upper)
    
    if (lambda_upper >= lambda_max) {
      break
    }
  }
  
  
  # ------------------------------------------------------------
  # 5. Construct a decreasing lambda grid
  #
  # For example, if lambda_upper = 4 and grid_ratio = sqrt(2):
  #
  # 4, 2.828, 2, 1.414, 1, 0.707, 0.5, ...
  #
  # This is finer than repeatedly halving lambda.
  # ------------------------------------------------------------
  
  lambda_vec <- numeric(0)
  
  current_lambda <- lambda_upper
  
  while (current_lambda >= lambda_min) {
    
    lambda_vec <- c(
      lambda_vec,
      current_lambda
    )
    
    current_lambda <-
      current_lambda / grid_ratio
  }
  
  
  # Always include lambda_min
  if (
    length(lambda_vec) == 0L ||
    tail(lambda_vec, 1L) > lambda_min
  ) {
    
    lambda_vec <- c(
      lambda_vec,
      lambda_min
    )
  }
  
  
  # Remove numerical duplicates if any
  lambda_vec <- unique(lambda_vec)
  
  
  # ------------------------------------------------------------
  # 6. Evaluate the complete lambda path
  # ------------------------------------------------------------
  
  diagnostics <- t(
    vapply(
      lambda_vec,
      evaluate_lambda,
      numeric(3)
    )
  )
  
  trace <- data.frame(
    lambda =
      lambda_vec,
    
    delta_sq =
      diagnostics[, "delta_sq"],
    
    delta =
      sqrt(diagnostics[, "delta_sq"]),
    
    noise_proportion =
      diagnostics[, "noise_proportion"],
    
    mean_noise_membership =
      diagnostics[, "mean_noise_membership"]
  )
  
  
  # ------------------------------------------------------------
  # 7. Optional printing
  # ------------------------------------------------------------
  
  if (verbose) {
    
    cat(
      "\nGlobal reconstruction-error scale =",
      base_scale_sq,
      "\n"
    )
    
    cat(
      "Adaptive upper lambda =",
      lambda_upper,
      "\n\n"
    )
    
    for (j in seq_len(nrow(trace))) {
      
      cat(
        sprintf(
          paste0(
            "lambda = %.6f | ",
            "delta = %.6f | ",
            "noise proportion = %.3f | ",
            "mean noise membership = %.3f\n"
          ),
          trace$lambda[j],
          trace$delta[j],
          trace$noise_proportion[j],
          trace$mean_noise_membership[j]
        )
      )
    }
  }
  
  
  # ------------------------------------------------------------
  # 8. Detect increases in the noise proportion
  #
  # lambda decreases down the table.
  # Therefore noise proportion should generally increase.
  # ------------------------------------------------------------
  
  jumps <- diff(
    trace$noise_proportion
  )
  
  large_jump <- which(
    jumps >= jump_threshold
  )
  
  
  # ------------------------------------------------------------
  # 9. Select lambda immediately BEFORE the first large jump
  # ------------------------------------------------------------
  
  if (length(large_jump) > 0L) {
    
    selected_idx <- large_jump[1L]
    
    selection <-
      "before_first_large_jump"
    
  } else if (
    length(jumps) > 0L &&
    any(jumps > 0)
  ) {
    
    # If no jump exceeds the threshold,
    # use the largest observed increase.
    
    selected_idx <- which.max(jumps)
    
    selection <-
      "before_largest_observed_jump"
    
  } else {
    
    # Completely flat path:
    # retain the largest / most conservative lambda.
    
    selected_idx <- 1L
    
    selection <-
      "largest_lambda_flat_path"
  }
  
  
  # ------------------------------------------------------------
  # 10. Final selected lambda and delta
  # ------------------------------------------------------------
  
  lambda_opt <-
    trace$lambda[selected_idx]
  
  delta_sq_opt <-
    lambda_opt * base_scale_sq
  
  delta_opt <-
    sqrt(delta_sq_opt)
  
  
  # ------------------------------------------------------------
  # 11. Return results
  # ------------------------------------------------------------
  
  list(
    
    lambda_opt =
      lambda_opt,
    
    delta_opt =
      delta_opt,
    
    delta_sq_opt =
      delta_sq_opt,
    
    base_scale_sq =
      base_scale_sq,
    
    lambda_upper =
      lambda_upper,
    
    selection =
      selection,
    
    selected_index =
      selected_idx,
    
    jump_size =
      if (selected_idx <= length(jumps)) {
        jumps[selected_idx]
      } else {
        NA_real_
      },
    
    trace =
      trace
  )
}

noise_membership_update_fast <- function(rec_err_sq, delta_sq, m, eps = 1e-12) {
  rec_err_sq <- as.matrix(rec_err_sq)
  if (length(delta_sq) != 1L || !is.finite(delta_sq) || delta_sq <= 0) {
    stop("delta_sq must be one positive finite value.")
  }
  # Treat the noise cluster as one additional cluster with constant squared
  # distance delta_sq.  The shared log-domain update is stable for m near 1.
  all_distances <- cbind(rec_err_sq, rep(delta_sq, nrow(rec_err_sq)))
  update_membership_fast(all_distances, m = m, eps = eps)
}

rfcpca_n_fast_once <- function(ts, k, m, startU = NULL, prep = NULL,
                               conver = 1e-4, rel_conver = 1e-5, maxit = 150,
                               verbose = TRUE, variance_threshold = 0.95, seed = NULL,
                               damping = 0.8, fix_components = TRUE, jump_threshold = 0.15,
                               rank_rule = c("median_series", "pooled_mean"),
                               delta_multiplier = 1,
                               delta_rule = c("literature_corrected", "robust_fence", "elbow"),
                               delta_fence_k = 2.0,
                               init_method = c("robust_lag", "fcpca", "random"),
                               init_confidence = 0.90) {
  delta_rule <- match.arg(delta_rule)
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  
  if (is.null(prep)) prep <- prepare_fcpca_data(ts)
  
  initial <- initial_state_fast(
    prep = prep,
    k = k,
    m = m,
    startU = startU,
    seed = seed,
    variance_threshold = variance_threshold,
    fix_components = fix_components,
    rank_rule = rank_rule,
    init_method = init_method,
    init_confidence = init_confidence
  )
  
  rec_error <- initial$reconstruction_error_matrix
  
  delta_res <- if (delta_rule == "literature_corrected") {
    find_optimal_delta_literature_fast(
      rec_error,
      m = m,
      jump_threshold = jump_threshold,
      verbose = FALSE
    )
  } else if (delta_rule == "elbow") {
    find_optimal_delta_fast(
      rec_error,
      jump_threshold = jump_threshold,
      verbose = FALSE
    )
  } else {
    list(lambda_opt = NA_real_, trace = NULL)
  }
  
  min_err0 <- apply(rec_error, 1, min)
  delta_location_initial <- stats::median(min_err0)
  delta_mad_scaled_initial <- stats::mad(min_err0, constant = 1.4826)
  
  robust_delta_sq <- delta_location_initial +
    delta_fence_k * delta_mad_scaled_initial
  
  if (!is.finite(robust_delta_sq) || robust_delta_sq <= 0) {
    robust_delta_sq <- as.numeric(
      stats::quantile(min_err0, .90, na.rm = TRUE)
    )
  }
  
  base_delta_sq <- if (delta_rule == "robust_fence") {
    robust_delta_sq
  } else if (delta_rule == "literature_corrected") {
    delta_res$delta_sq_opt
  } else {
    delta_res$delta_opt^2
  }
  
  delta_sq <- max(delta_multiplier^2 * base_delta_sq, 1e-12)
  
  U <- noise_membership_update_fast(rec_error, delta_sq, m)
  U_valid <- U[, seq_len(k), drop = FALSE]
  
  fixed_k1 <- if (isTRUE(fix_components)) initial$n_components_lag01 else NULL
  fixed_k2 <- if (isTRUE(fix_components)) initial$n_components_lag02 else NULL
  
  iteration <- 0L
  obj <- Inf
  prev_obj <- Inf
  rel_obj_change <- Inf
  axes <- initial$projection_axes
  converged <- FALSE
  
  repeat {
    iteration <- iteration + 1L
    
    weighted_cov <- weighted_covariances_fast(
      U_valid, m, prep$sigma1, prep$sigma2
    )
    
    axes <- projection_axes_fast(
      weighted_cov,
      variance_threshold = variance_threshold,
      fixed_k1 = fixed_k1,
      fixed_k2 = fixed_k2
    )
    
    rec_error_new <- reconstruction_error_fast(prep, axes)
    U_raw <- noise_membership_update_fast(rec_error_new, delta_sq, m)
    U_raw_valid <- U_raw[, seq_len(k), drop = FALSE]
    
    U_valid_new <- damping * U_raw_valid +
      (1 - damping) * U_valid
    
    U_noise_new <- pmax(0, 1 - rowSums(U_valid_new))
    U_new <- cbind(U_valid_new, U_noise_new)
    
    diffU <- max(abs(U - U_new))
    U <- U_new
    U_valid <- U[, seq_len(k), drop = FALSE]
    
    prev_obj <- obj
    obj <- sum((U_valid^m) * rec_error_new) +
      sum((U[, k + 1L]^m) * delta_sq)
    
    rel_obj_change <- relative_change(prev_obj, obj)
    rec_error <- rec_error_new
    
    if (verbose) {
      cat(sprintf(
        "Iteration %d (RFCPCA-N): Obj = %.6f, dU = %.6g, relObj = %.6g, delta = %.6g\n",
        iteration, obj, diffU, rel_obj_change, sqrt(delta_sq)
      ))
    }
    
    if (iteration >= 5L &&
        diffU <= conver &&
        rel_obj_change <= rel_conver) {
      converged <- TRUE
      break
    }
    
    if (iteration >= maxit) break
  }
  
  final_weighted_cov <- weighted_covariances_fast(
    U_valid, m, prep$sigma1, prep$sigma2
  )
  axes <- projection_axes_fast(
    final_weighted_cov,
    variance_threshold = variance_threshold,
    fixed_k1 = fixed_k1,
    fixed_k2 = fixed_k2
  )
  rec_error <- reconstruction_error_fast(prep, axes)
  
  obj <- sum((U_valid^m) * rec_error) +
    sum((U[, k + 1L]^m) * delta_sq)
  
  valid_hard <- max.col(U_valid, ties.method = "first")
  noise_is_winner <- U[, k + 1L] >= apply(U_valid, 1, max)
  substantive_hard_cluster <- valid_hard
  valid_hard[noise_is_winner] <- NA_integer_
  
  list(
    method = "RFCPCA-N",
    membership_matrix = U,
    valid_membership_matrix = U_valid,
    noise_membership = U[, k + 1L],
    projection_axes = axes,
    reconstruction_error_matrix = rec_error,
    weighted_covariances = final_weighted_cov,
    delta_opt = sqrt(delta_sq),
    delta_sq = delta_sq,
    lambda_opt = delta_res$lambda_opt,
    delta_rule = delta_rule,
    delta_fence_sq = robust_delta_sq,
    delta_location_initial = delta_location_initial,
    delta_mad_scaled_initial = delta_mad_scaled_initial,
    delta_fence_k = delta_fence_k,
    initialization = initial$initialization,
    initial_cluster_sizes = initial$initial_cluster_sizes,
    initial_features_retained = initial$initial_features_retained,
    initial_pca_components = initial$initial_pca_components,
    initial_algorithm = initial$initial_algorithm,
    rank_rule = initial$rank_rule,
    n_components_lag01 = initial$n_components_lag01,
    n_components_lag02 = initial$n_components_lag02,
    per_series_rank_lag1 = initial$per_series_rank_lag1,
    per_series_rank_lag2 = initial$per_series_rank_lag2,
    trace = delta_res$trace,
    objective = obj,
    S_value = compute_original_CVI_fast(obj, axes, nrow(U)),
    CVI = compute_original_CVI_fast(obj, axes, nrow(U)),
    hard_cluster = valid_hard,
    substantive_hard_cluster = substantive_hard_cluster,
    noise_is_winner = noise_is_winner,
    retained_fraction = mean(!noise_is_winner),
    noise_fraction = mean(noise_is_winner),
    iterations = iteration,
    converged = converged,
    k = k,
    m = m,
    optimal_k = k,
    optimal_m = m,
    damping = damping,
    fix_components = isTRUE(fix_components),
    conver = conver,
    rel_conver = rel_conver
  )
}

identify_trim_set_fast <- function(err_mat, U, m, alpha, rule = c("h", "e"), eps = 1e-12) {
  rule <- match.arg(rule); n <- nrow(err_mat); H <- max(1L, floor((1 - alpha) * n))
  if (rule == "h") {
    pow <- 1 / (1 - m)
    h <- rowSums((pmax(err_mat, eps))^pow)^(1 - m)
    ord <- order(h)
  } else {
    e <- rowSums((U^m) * pmax(err_mat, eps))
    ord <- order(e)
  }
  keep_id <- ord[seq_len(H)]
  trim <- rep(TRUE, n); trim[keep_id] <- FALSE
  trim
}

renormalize_trimmed_U <- function(U, trim_idx) {
  U_new <- U; U_new[trim_idx, ] <- 0
  rs <- rowSums(U_new); rs[!is.finite(rs) | rs <= 0] <- 1
  U_new / rs
}

trimmed_membership_update_fast <- function(rec_error, m, trim_idx, eps = 1e-12) {
  U_raw <- update_membership_fast(rec_error, m, eps = eps)
  renormalize_trimmed_U(U_raw, trim_idx)
}

rfcpca_t_fast_once <- function(ts, k, m, alpha, startU = NULL, prep = NULL,
                               conver = 1e-4, rel_conver = 1e-5, maxit = 150,
                               verbose = TRUE, variance_threshold = 0.95, seed = NULL,
                               damping = 0.8, fix_components = TRUE,
                               rank_rule = c("median_series", "pooled_mean"),
                               trim_rule = c("h", "e"),
                               init_method = c("robust_lag", "fcpca", "random"),
                               init_confidence = 0.90) {
  trim_rule <- match.arg(trim_rule)
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  
  if (!is.finite(alpha) || alpha < 0 || alpha >= 1) {
    stop("alpha must be in [0, 1).")
  }
  
  if (is.null(prep)) prep <- prepare_fcpca_data(ts)
  
  initial <- initial_state_fast(
    prep = prep,
    k = k,
    m = m,
    startU = startU,
    seed = seed,
    variance_threshold = variance_threshold,
    fix_components = fix_components,
    rank_rule = rank_rule,
    init_method = init_method,
    init_confidence = init_confidence
  )
  
  U <- initial$membership_matrix
  rec_error <- initial$reconstruction_error_matrix
  
  fixed_k1 <- if (isTRUE(fix_components)) initial$n_components_lag01 else NULL
  fixed_k2 <- if (isTRUE(fix_components)) initial$n_components_lag02 else NULL
  axes <- initial$projection_axes
  
  trim_idx <- identify_trim_set_fast(
    rec_error, U, m, alpha, rule = trim_rule
  )
  U <- renormalize_trimmed_U(U, trim_idx)
  
  iteration <- 0L
  obj <- Inf
  prev_obj <- Inf
  rel_obj_change <- Inf
  converged <- FALSE
  
  repeat {
    iteration <- iteration + 1L
    
    weighted_cov <- weighted_covariances_fast(
      U, m, prep$sigma1, prep$sigma2
    )
    
    axes <- projection_axes_fast(
      weighted_cov,
      variance_threshold = variance_threshold,
      fixed_k1 = fixed_k1,
      fixed_k2 = fixed_k2
    )
    
    rec_error_new <- reconstruction_error_fast(prep, axes)
    trim_idx_new <- identify_trim_set_fast(
      rec_error_new, U, m, alpha, rule = trim_rule
    )
    
    U_raw <- trimmed_membership_update_fast(
      rec_error_new, m, trim_idx_new
    )
    
    U_damped <- damping * U_raw + (1 - damping) * U
    U_damped[trim_idx_new, ] <- 0
    U_new <- renormalize_trimmed_U(U_damped, trim_idx_new)
    
    diffU <- max(abs(U - U_new))
    U <- U_new
    trim_idx <- trim_idx_new
    
    prev_obj <- obj
    obj <- sum((U^m) * rec_error_new)
    rel_obj_change <- relative_change(prev_obj, obj)
    rec_error <- rec_error_new
    
    if (verbose) {
      cat(sprintf(
        "Iteration %d (RFCPCA-T): Obj = %.6f, dU = %.6g, relObj = %.6g, keep = %d, alpha = %.2f\n",
        iteration, obj, diffU, rel_obj_change,
        sum(!trim_idx), alpha
      ))
    }
    
    if (iteration >= 5L &&
        diffU <= conver &&
        rel_obj_change <= rel_conver) {
      converged <- TRUE
      break
    }
    
    if (iteration >= maxit) break
  }
  
  final_weighted_cov <- weighted_covariances_fast(
    U, m, prep$sigma1, prep$sigma2
  )
  axes <- projection_axes_fast(
    final_weighted_cov,
    variance_threshold = variance_threshold,
    fixed_k1 = fixed_k1,
    fixed_k2 = fixed_k2
  )
  rec_error <- reconstruction_error_fast(prep, axes)
  
  n_keep <- sum(!trim_idx)
  obj <- sum((U^m) * rec_error)
  
  hard_cluster <- max.col(U, ties.method = "first")
  hard_cluster[trim_idx] <- NA_integer_
  posthoc_membership <- update_membership_fast(rec_error, m)
  posthoc_hard_cluster <- max.col(
    posthoc_membership,
    ties.method = "first"
  )
  
  list(
    method = "RFCPCA-T",
    membership_matrix = U,
    projection_axes = axes,
    reconstruction_error_matrix = rec_error,
    weighted_covariances = final_weighted_cov,
    trim_set = trim_idx,
    kept_set = !trim_idx,
    alpha_used = alpha,
    objective = obj,
    S_value = compute_original_CVI_fast(
      obj, axes, max(n_keep, 1L)
    ),
    CVI = compute_original_CVI_fast(
      obj, axes, max(n_keep, 1L)
    ),
    hard_cluster = hard_cluster,
    posthoc_membership_matrix = posthoc_membership,
    posthoc_hard_cluster = posthoc_hard_cluster,
    retained_fraction = mean(!trim_idx),
    trimmed_fraction = mean(trim_idx),
    iterations = iteration,
    converged = converged,
    k = k,
    m = m,
    alpha = alpha,
    optimal_k = k,
    optimal_m = m,
    optimal_alpha = alpha,
    initialization = initial$initialization,
    initial_cluster_sizes = initial$initial_cluster_sizes,
    initial_features_retained = initial$initial_features_retained,
    initial_pca_components = initial$initial_pca_components,
    initial_algorithm = initial$initial_algorithm,
    rank_rule = initial$rank_rule,
    n_components_lag01 = initial$n_components_lag01,
    n_components_lag02 = initial$n_components_lag02,
    per_series_rank_lag1 = initial$per_series_rank_lag1,
    per_series_rank_lag2 = initial$per_series_rank_lag2,
    damping = damping,
    fix_components = isTRUE(fix_components),
    conver = conver,
    rel_conver = rel_conver
  )
}

# Initializer smoke-test helper ------------------------------------------------
rfcpca_initializer_check <- function(ts, k = 2, m = 1.5,
                                     seed = 123,
                                     confidence = 0.90) {
  prep <- prepare_fcpca_data(ts)
  
  U0 <- robust_membership_init(
    prep = prep,
    k = k,
    m = m,
    seed = seed,
    confidence = confidence
  )
  
  list(
    dim = dim(U0),
    row_sum_range = range(rowSums(U0)),
    max_membership_summary = summary(apply(U0, 1, max)),
    cluster_sizes = attr(U0, "cluster_sizes"),
    features_retained = attr(U0, "features_retained"),
    feature_matrix_dim = attr(U0, "feature_matrix_dim"),
    scaled_feature_matrix_dim = attr(U0, "scaled_feature_matrix_dim"),
    pca_components_used = attr(U0, "pca_components_used"),
    score_matrix_dim = attr(U0, "score_matrix_dim"),
    initializer_algorithm = attr(U0, "initializer_algorithm"),
    head = utils::head(U0, 10)
  )
}

# Diagnostic helper ------------------------------------------------------------
# Useful for checking whether the fitted cluster subspaces have collapsed.
rfcpca_diagnostics <- function(fit) {
  U <- as.matrix(fit$membership_matrix)
  R <- as.matrix(fit$reconstruction_error_matrix)
  
  if (ncol(R) < 2L) {
    stop("Diagnostics require at least two regular clusters.")
  }
  
  max_u <- apply(U[, seq_len(ncol(R)), drop = FALSE], 1, max)
  
  # For k=2 this is the direct relative reconstruction-error gap used in
  # debugging the EEG example.  For k>2, compare the two smallest errors.
  sorted_R <- t(apply(R, 1, sort))
  best <- sorted_R[, 1]
  second <- sorted_R[, 2]
  rel_gap <- abs(second - best) / pmax(best, 1e-12)
  
  list(
    max_membership_summary = summary(max_u),
    mixed_fraction_0.70 = mean(max_u < 0.70),
    relative_gap_summary = summary(rel_gap),
    relative_gap_quantiles = stats::quantile(
      rel_gap,
      probs = c(0, .01, .05, .10, .25, .50, .75, .90, .95, .99, 1),
      na.rm = TRUE
    )
  )
}


# Auto-selection wrappers ------------------------------------------------------

RFCPCA_E <- function(ts, k = NULL, m = NULL, startU = NULL,
                     conver = 1e-3, rel_conver = 1e-7, maxit = 50,
                     verbose = TRUE, parallel = TRUE,
                     variance_threshold = 0.95, seed = TRUE,
                     damping = 0.8, fix_components = TRUE,
                     rank_rule = c("median_series", "pooled_mean"),
                     init_method = c("robust_lag", "fcpca", "random"),
                     init_confidence = 0.90,
                     beta_rule = c("paper_mean", "robust_fence"),
                     beta_scale = NULL,
                     beta_tail_weight = 0.80,
                     beta_fence_k = 2.5) {
  init_method <- match.arg(init_method)
  rank_rule <- match.arg(rank_rule)
  beta_rule <- match.arg(beta_rule)
  
  auto_mode <- is.null(k) || is.null(m) ||
    length(k) > 1L || length(m) > 1L
  
  k_range <- if (is.null(k)) 2:6 else k
  m_range <- if (is.null(m)) c(1.05, 1.1, 1.2, 1.4, 1.6, 1.8, 2.0) else m
  grid <- expand.grid(k = k_range, m = m_range)
  
  prep <- prepare_fcpca_data(ts)
  pmap <- .get_parallel_map(parallel, seed)
  
  run_one <- function(idx) {
    if (verbose) {
      cat(sprintf(
        "Running RFCPCA-E: k = %d, m = %.2f\n",
        grid$k[idx], grid$m[idx]
      ))
    }
    
    rfcpca_e_fast_once(
      ts = ts,
      k = grid$k[idx],
      m = grid$m[idx],
      startU = startU,
      prep = prep,
      conver = conver,
      rel_conver = rel_conver,
      maxit = maxit,
      verbose = FALSE,
      variance_threshold = variance_threshold,
      seed = .grid_seed(seed, idx),
      damping = damping,
      fix_components = fix_components,
      rank_rule = rank_rule,
      beta_scale = beta_scale,
      beta_tail_weight = beta_tail_weight,
      beta_fence_k = beta_fence_k,
      beta_rule = beta_rule,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  results <- pmap(seq_len(nrow(grid)), run_one)
  
  if (!auto_mode) {
    final <- results[[1L]]
    final$all_results <- results
    return(final)
  }
  
  S <- vapply(results, `[[`, numeric(1), "S_value")
  best <- which.min(S)
  
  final <- results[[best]]
  final$optimal_k <- grid$k[best]
  final$optimal_m <- grid$m[best]
  final$all_results <- results
  final$search_grid <- grid
  final
}

RFCPCA_N <- function(ts, k = NULL, m = NULL, startU = NULL,
                     conver = 1e-3, rel_conver = 1e-7, maxit = 50,
                     verbose = TRUE, parallel = TRUE,
                     variance_threshold = 0.95, seed = TRUE,
                     damping = 0.8, fix_components = TRUE,
                     rank_rule = c("median_series", "pooled_mean"),
                     jump_threshold = 0.3,
                     delta_rule = c("literature_corrected", "robust_fence", "elbow"),
                     delta_multiplier = 1,
                     delta_fence_k = 2.5,
                     init_method = c("robust_lag", "fcpca", "random"),
                     init_confidence = 0.90) {
  delta_rule <- match.arg(delta_rule)
  init_method <- match.arg(init_method)
  rank_rule <- match.arg(rank_rule)
  
  auto_mode <- is.null(k) || is.null(m) ||
    length(k) > 1L || length(m) > 1L
  
  k_range <- if (is.null(k)) 2:6 else k
  m_range <- if (is.null(m)) c(1.05, 1.1, 1.2, 1.4, 1.6, 1.8, 2.0) else m
  grid <- expand.grid(k = k_range, m = m_range)
  
  prep <- prepare_fcpca_data(ts)
  pmap <- .get_parallel_map(parallel, seed)
  
  run_one <- function(idx) {
    if (verbose) {
      cat(sprintf(
        "Running RFCPCA-N: k = %d, m = %.2f\n",
        grid$k[idx], grid$m[idx]
      ))
    }
    
    rfcpca_n_fast_once(
      ts = ts,
      k = grid$k[idx],
      m = grid$m[idx],
      startU = startU,
      prep = prep,
      conver = conver,
      rel_conver = rel_conver,
      maxit = maxit,
      verbose = FALSE,
      variance_threshold = variance_threshold,
      seed = .grid_seed(seed, idx),
      damping = damping,
      fix_components = fix_components,
      rank_rule = rank_rule,
      jump_threshold = jump_threshold,
      delta_multiplier = delta_multiplier,
      delta_rule = delta_rule,
      delta_fence_k = delta_fence_k,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  results <- pmap(seq_len(nrow(grid)), run_one)
  
  if (!auto_mode) {
    final <- results[[1L]]
    final$all_results <- results
    return(final)
  }
  
  S <- vapply(results, `[[`, numeric(1), "S_value")
  best <- which.min(S)
  
  final <- results[[best]]
  final$optimal_k <- grid$k[best]
  final$optimal_m <- grid$m[best]
  final$all_results <- results
  final$search_grid <- grid
  final
}

RFCPCA_T <- function(ts, k = NULL, m = NULL, alpha = NULL,
                     startU = NULL,
                     conver = 1e-3, rel_conver = 1e-7, maxit = 50,
                     verbose = TRUE, parallel = TRUE,
                     variance_threshold = 0.95, seed = TRUE,
                     damping = 0.8, fix_components = TRUE,
                     rank_rule = c("median_series", "pooled_mean"),
                     trim_rule = c("h", "e"),
                     init_method = c("robust_lag", "fcpca", "random"),
                     init_confidence = 0.90) {
  trim_rule <- match.arg(trim_rule)
  rank_rule <- match.arg(rank_rule)
  init_method <- match.arg(init_method)
  
  auto_mode <- is.null(k) || is.null(m) || length(k) > 1L ||
    length(m) > 1L || is.null(alpha) || length(alpha) > 1L
  
  k_range <- if (is.null(k)) 2:6 else k
  m_range <- if (is.null(m)) c(1.05, 1.1, 1.2, 1.4, 1.6, 1.8, 2.0) else m
  alpha_range <- if (is.null(alpha)) {
    c(0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5)
  } else {
    alpha
  }
  
  grid <- expand.grid(
    k = k_range,
    m = m_range,
    alpha = alpha_range
  )
  
  prep <- prepare_fcpca_data(ts)
  pmap <- .get_parallel_map(parallel, seed)
  
  run_one <- function(idx) {
    if (verbose) {
      cat(sprintf(
        "Running RFCPCA-T: k = %d, m = %.2f, alpha = %.2f\n",
        grid$k[idx], grid$m[idx], grid$alpha[idx]
      ))
    }
    
    rfcpca_t_fast_once(
      ts = ts,
      k = grid$k[idx],
      m = grid$m[idx],
      alpha = grid$alpha[idx],
      startU = startU,
      prep = prep,
      conver = conver,
      rel_conver = rel_conver,
      maxit = maxit,
      verbose = FALSE,
      variance_threshold = variance_threshold,
      seed = .grid_seed(seed, idx),
      damping = damping,
      fix_components = fix_components,
      rank_rule = rank_rule,
      trim_rule = trim_rule,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  results <- pmap(seq_len(nrow(grid)), run_one)
  
  if (!auto_mode) {
    final <- results[[1L]]
    final$all_results <- results
    return(final)
  }
  
  S <- vapply(
    results,
    `[[`,
    numeric(1),
    "S_value"
  )
  
  converged <- vapply(
    results,
    function(x) isTRUE(x$converged),
    logical(1)
  )
  
  valid <- converged & is.finite(S)
  
  if (!any(valid)) {
    stop("No converged RFCPCA-T solution was found in the tuning grid.")
  }
  
  S_select <- S
  S_select[!valid] <- Inf
  
  best <- which.min(S_select)
  
  final <- results[[best]]
  
  final$optimal_k <- grid$k[best]
  final$optimal_m <- grid$m[best]
  final$optimal_alpha <- grid$alpha[best]
  
  final$all_results <- results
  final$search_grid <- grid
  
  final
}

RFCPCA_ALL <- function(ts, k = 2, m = 1.6, alpha = 0.2,
                       conver = 1e-3, rel_conver = 1e-7, maxit = 50,
                       damping = 0.8, parallel = FALSE, seed = 123,
                       variance_threshold = 0.95,
                       fix_components = TRUE,
                       rank_rule = c("median_series", "pooled_mean"),
                       trim_rule = "h",
                       init_method = "robust_lag",
                       init_confidence = 0.90,
                       run_E = TRUE, run_N = TRUE, run_T = TRUE) {
  rank_rule <- match.arg(rank_rule)
  out <- list()
  
  if (run_E) {
    out$RFCPCA_E <- RFCPCA_E(
      ts = ts, k = k, m = m,
      conver = conver, rel_conver = rel_conver, maxit = maxit,
      damping = damping, parallel = parallel, seed = seed,
      variance_threshold = variance_threshold,
      fix_components = fix_components,
      rank_rule = rank_rule,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  if (run_N) {
    out$RFCPCA_N <- RFCPCA_N(
      ts = ts, k = k, m = m,
      conver = conver, rel_conver = rel_conver, maxit = maxit,
      damping = damping, parallel = parallel, seed = seed,
      variance_threshold = variance_threshold,
      fix_components = fix_components,
      rank_rule = rank_rule,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  if (run_T) {
    out$RFCPCA_T <- RFCPCA_T(
      ts = ts, k = k, m = m, alpha = alpha,
      conver = conver, rel_conver = rel_conver, maxit = maxit,
      damping = damping, parallel = parallel, seed = seed,
      variance_threshold = variance_threshold,
      fix_components = fix_components,
      rank_rule = rank_rule,
      trim_rule = trim_rule,
      init_method = init_method,
      init_confidence = init_confidence
    )
  }
  
  out
}

time_method <- function(expr) {
  t <- system.time({ value <- eval.parent(substitute(expr)) })
  list(result = value, elapsed_sec = unname(t["elapsed"]))
}

###############################################################################
# Example usage
###############################################################################
# Optional parallel setup -- run ONCE before a large grid search:
# if (requireNamespace("future", quietly = TRUE)) {
#   future::plan(future::multisession, workers = 4)
# }
#
# After ALL RFCPCA computations:
# if (requireNamespace("future", quietly = TRUE)) {
#   future::plan(future::sequential)
#   gc()
# }

#
# First run this smoke test after sourcing the file:
# rfcpca_initializer_check(EEGsample_subject, k = 2, m = 1.2, seed = 123)
#
# Recommended robust initialization for RFCPCA:
# res_e <- RFCPCA_E(EEGsample_subject, k = 2, m = 1.2,
#                   init_method = "robust_lag",
#                   parallel = FALSE, seed = 123)
# rfcpca_diagnostics(res_e)
#
# Inspect the initializer directly:
# prep <- prepare_fcpca_data(EEGsample_subject)
# U0 <- robust_membership_init(prep, k = 2, m = 1.2,
#                              seed = 123, confidence = 0.90)
# head(U0)
# attr(U0, "cluster_sizes")
#
# source("RFCPCA_all_fast_stable_revised_paper_aligned_v6_final.R")
#
# out_e <- time_method(RFCPCA_E(EEGsample_subject, k = 2, m = 1.6,
#                              parallel = FALSE, seed = 123))
# out_e$elapsed_sec
# res_e <- out_e$result
#
# out_n <- time_method(RFCPCA_N(EEGsample_subject, k = 2, m = 1.6,
#                              parallel = FALSE, seed = 1))
# res_n <- out_n$result
#
# out_t <- time_method(RFCPCA_T(EEGsample_subject, k = 2, m = 1.6, alpha = 0.2,
#                              parallel = FALSE, seed = 1))
# res_t <- out_t$result
#
# all_res <- RFCPCA_ALL(EEGsample_subject, k = 2, m = 1.6, alpha = 0.2)
