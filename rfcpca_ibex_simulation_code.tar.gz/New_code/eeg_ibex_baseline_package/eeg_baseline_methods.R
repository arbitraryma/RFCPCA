
###############################################################################
# eeg_baseline_methods.R
# Baselines for subject-wise EEG clustering comparison with RFCPCA
#
# Methods implemented here:
#   1) Band-power + fuzzy C-means
#   2) Multivariate DTW + DBA k-means
#   3) Shrinkage covariance + intrinsic Riemannian k-means
#   4) Spectral clustering on lag-1/lag-2 covariance features
#   5) EMTC wrapper (calls a Python helper / official EMTC repository)
#
# Expected input:
#   ts = list of N matrices, one matrix per EEG epoch, T x p.
#
# IMPORTANT:
#   Ground-truth labels are NEVER used inside the clustering methods.
###############################################################################

# =============================================================================
# Common utilities
# =============================================================================

validate_mts_list <- function(ts) {
  if (!is.list(ts) || length(ts) < 2L) {
    stop("ts must be a list containing at least two multivariate time series.")
  }
  mats <- lapply(ts, as.matrix)
  nr <- vapply(mats, nrow, integer(1))
  nc <- vapply(mats, ncol, integer(1))
  if (any(nr < 3L)) stop("Every epoch must have at least 3 time points.")
  if (length(unique(nc)) != 1L) stop("All epochs must have the same number of channels.")
  finite_ok <- vapply(mats, function(x) all(is.finite(x)), logical(1))
  if (!all(finite_ok)) stop("All EEG values must be finite.")
  invisible(TRUE)
}

standardize_epoch <- function(x) {
  x <- as.matrix(x)
  mu <- colMeans(x)
  s <- apply(x, 2, stats::sd)
  s[!is.finite(s) | s <= 1e-12] <- 1
  sweep(sweep(x, 2, mu, "-"), 2, s, "/")
}

rand_index <- function(pred, truth) {
  pred <- as.vector(pred)
  truth <- as.vector(truth)
  if (length(pred) != length(truth)) stop("pred and truth must have equal length.")
  ok <- complete.cases(pred, truth)
  pred <- pred[ok]
  truth <- truth[ok]
  n <- length(pred)
  if (n < 2L) return(NA_real_)

  tab <- table(pred, truth)
  choose2 <- function(x) x * (x - 1) / 2

  a <- sum(choose2(tab))
  same_pred <- sum(choose2(rowSums(tab)))
  same_true <- sum(choose2(colSums(tab)))
  total <- choose2(n)
  b <- total - same_pred - same_true + a

  (a + b) / total
}

evaluate_clustering <- function(pred, truth) {
  if (!requireNamespace("mclust", quietly = TRUE)) {
    stop("Package 'mclust' is required. Install with install.packages('mclust').")
  }
  pred <- as.vector(pred)
  truth <- as.vector(truth)
  ok <- complete.cases(pred, truth)
  pred <- pred[ok]
  truth <- truth[ok]

  data.frame(
    RI = rand_index(pred, truth),
    ARI = mclust::adjustedRandIndex(pred, truth)
  )
}

# =============================================================================
# 1) Band-power + FCM
# =============================================================================

.one_sided_psd <- function(x, fs) {
  x <- as.numeric(x)
  x <- x - mean(x)
  n <- length(x)

  fx <- fft(x)
  kmax <- floor(n / 2)
  idx <- 0:kmax
  freq <- idx * fs / n
  psd <- (Mod(fx[idx + 1L])^2) / (fs * n)

  if (n %% 2L == 0L) {
    if (length(psd) > 2L) psd[2:(length(psd) - 1L)] <- 2 * psd[2:(length(psd) - 1L)]
  } else {
    if (length(psd) > 1L) psd[2:length(psd)] <- 2 * psd[2:length(psd)]
  }

  list(freq = freq, psd = psd, df = fs / n)
}

.bandpower_single <- function(x, fs, bands, relative = TRUE, total_band = c(0.5, 45)) {
  z <- .one_sided_psd(x, fs)
  bp <- vapply(seq_len(nrow(bands)), function(j) {
    keep <- z$freq >= bands[j, 1] & z$freq <= bands[j, 2]
    sum(z$psd[keep]) * z$df
  }, numeric(1))

  if (relative) {
    keep_total <- z$freq >= total_band[1] & z$freq <= total_band[2]
    total <- sum(z$psd[keep_total]) * z$df
    bp <- bp / max(total, .Machine$double.eps)
  }
  bp
}

extract_bandpower_features <- function(
    ts,
    fs = 128,
    bands = rbind(
      delta = c(0.5, 3.5),
      theta = c(4.5, 8.5),
      alpha = c(9.5, 12.5),
      beta  = c(15, 25),
      gamma = c(35, 45)
    ),
    relative = TRUE,
    log_transform = TRUE) {

  validate_mts_list(ts)
  mats <- lapply(ts, as.matrix)
  p <- ncol(mats[[1L]])
  X <- matrix(NA_real_, nrow = length(mats), ncol = p * nrow(bands))

  for (i in seq_along(mats)) {
    feat <- unlist(lapply(seq_len(p), function(ch) {
      .bandpower_single(mats[[i]][, ch], fs = fs, bands = bands, relative = relative)
    }), use.names = FALSE)

    if (log_transform) feat <- log(feat + 1e-10)
    X[i, ] <- feat
  }
  X
}

fit_bandpower_fcm <- function(
    ts,
    k = 2,
    fs = 128,
    m = 2,
    seed = 123,
    relative = TRUE,
    log_transform = TRUE) {

  if (!requireNamespace("e1071", quietly = TRUE)) {
    stop("Package 'e1071' is required. Install with install.packages('e1071').")
  }

  X <- extract_bandpower_features(
    ts = ts, fs = fs, relative = relative, log_transform = log_transform
  )
  Xs <- scale(X)
  Xs[!is.finite(Xs)] <- 0

  set.seed(seed)
  fit <- e1071::cmeans(
    x = Xs,
    centers = k,
    iter.max = 200,
    m = m,
    method = "cmeans",
    dist = "euclidean"
  )

  list(
    method = "Bandpower_FCM",
    cluster = as.integer(fit$cluster),
    membership = fit$membership,
    features = X,
    model = fit,
    k = k,
    m = m
  )
}

# =============================================================================
# 2) Multivariate DTW + DBA
#
# We deliberately run each restart with nrep=1 and choose the restart with the
# smallest sum of distances to assigned centroids. This avoids the dtwclust
# nrep>1 return-type ambiguity and remains completely unsupervised.
# =============================================================================

fit_dtw_dba <- function(
    ts,
    k = 2,
    seed = 123,
    nrep = 5L,
    z_normalize = TRUE,
    window.size = 38L,
    iter.max = 50L,
    trace = FALSE) {

  if (!requireNamespace("dtwclust", quietly = TRUE)) {
    stop("Package 'dtwclust' is required. Install with install.packages('dtwclust').")
  }

  validate_mts_list(ts)

  series <- lapply(ts, function(x) {
    x <- as.matrix(x)
    if (z_normalize) standardize_epoch(x) else x
  })

  one_run <- function(rep_id) {
    this_seed <- as.integer(seed) + rep_id - 1L
    set.seed(this_seed)

    ctrl <- dtwclust::partitional_control(
      nrep = 1L,
      iter.max = as.integer(iter.max)
    )

    if (is.null(window.size)) {
      fit <- dtwclust::tsclust(
        series = series,
        type = "partitional",
        k = as.integer(k),
        distance = "dtw_basic",
        centroid = "dba",
        control = ctrl,
        seed = this_seed,
        trace = trace
      )
    } else {
      fit <- dtwclust::tsclust(
        series = series,
        type = "partitional",
        k = as.integer(k),
        distance = "dtw_basic",
        centroid = "dba",
        control = ctrl,
        seed = this_seed,
        trace = trace,
        args = dtwclust::tsclust_args(
          dist = list(window.size = as.integer(window.size)),
          cent = list(window.size = as.integer(window.size))
        )
      )
    }

    if (!methods::is(fit, "PartitionalTSClusters")) {
      stop("dtwclust returned an unexpected object class: ", paste(class(fit), collapse = ", "))
    }

    obj <- sum(as.numeric(fit@cldist[, 1L]))
    list(fit = fit, objective = obj, seed = this_seed)
  }

  runs <- lapply(seq_len(as.integer(nrep)), one_run)
  objs <- vapply(runs, `[[`, numeric(1), "objective")
  if (all(!is.finite(objs))) stop("All DTW repetitions failed to produce finite objectives.")

  best <- which.min(objs)
  fit <- runs[[best]]$fit

  list(
    method = "DTW_DBA",
    cluster = as.integer(fit@cluster),
    model = fit,
    all_objectives = objs,
    best_repetition = best,
    best_objective = objs[best],
    k = k,
    nrep = nrep,
    window.size = window.size
  )
}

# =============================================================================
# 3) Shrinkage covariance + intrinsic Riemannian k-means
# =============================================================================

fit_riemannian_covariance <- function(
    ts,
    k = 2,
    seed = 123,
    nstart = 20L,
    maxiter = 100L,
    standardize_channels = TRUE,
    shrinkage = TRUE) {

  if (!requireNamespace("Riemann", quietly = TRUE)) {
    stop("Package 'Riemann' is required. Install with install.packages('Riemann').")
  }
  if (shrinkage && !requireNamespace("corpcor", quietly = TRUE)) {
    stop("Package 'corpcor' is required. Install with install.packages('corpcor').")
  }

  validate_mts_list(ts)

  cov_list <- lapply(ts, function(x) {
    x <- as.matrix(x)
    if (standardize_channels) x <- standardize_epoch(x)

    S <- if (shrinkage) {
      corpcor::cov.shrink(x, verbose = FALSE)
    } else {
      stats::cov(x)
    }

    S <- (S + t(S)) / 2

    # Strict SPD safeguard.
    ev <- eigen(S, symmetric = TRUE, only.values = TRUE)$values
    if (min(ev) <= 1e-8) {
      S <- S + diag(abs(min(ev)) + 1e-6, nrow(S))
    }
    S
  })

  riem_obj <- Riemann::wrap.spd(cov_list)

  set.seed(seed)
  fit <- Riemann::riem.kmeans(
    riemobj = riem_obj,
    k = as.integer(k),
    geometry = "intrinsic",
    algorithm = "Lloyd",
    init = "plus",
    maxiter = as.integer(maxiter),
    nstart = as.integer(nstart)
  )

  list(
    method = "Riemannian",
    cluster = as.integer(fit$cluster),
    covariance = cov_list,
    model = fit,
    WCSS = fit$score,
    k = k
  )
}

# =============================================================================
# 4) Spectral clustering on lag-covariance features
# =============================================================================

.lag_cov_block <- function(x, lag) {
  x <- standardize_epoch(x)
  n <- nrow(x)
  if (n <= lag) stop("Epoch too short for lag ", lag)

  gamma0 <- stats::cov(x)
  x_t <- x[seq_len(n - lag), , drop = FALSE]
  x_lag <- x[(lag + 1L):n, , drop = FALSE]
  gamma_lag <- stats::cov(x_t, x_lag)

  rbind(
    cbind(gamma0, gamma_lag),
    cbind(t(gamma_lag), gamma0)
  )
}

extract_lag_cov_features <- function(ts, lags = c(1L, 2L)) {
  validate_mts_list(ts)

  feats <- lapply(ts, function(x) {
    unlist(lapply(lags, function(L) {
      B <- .lag_cov_block(as.matrix(x), L)
      B[upper.tri(B, diag = TRUE)]
    }), use.names = FALSE)
  })

  X <- do.call(rbind, feats)
  storage.mode(X) <- "double"
  X
}

fit_lag_spectral <- function(
    ts,
    k = 2,
    lags = c(1L, 2L),
    seed = 123,
    sigma = NULL,
    nstart = 50L,
    robust_scale = TRUE) {

  X <- extract_lag_cov_features(ts, lags = lags)

  if (robust_scale) {
    med <- apply(X, 2, stats::median)
    sc <- apply(X, 2, stats::mad, constant = 1.4826)
    keep <- is.finite(sc) & sc > 1e-10
    if (!any(keep)) stop("No informative lag-covariance features.")

    Z <- sweep(X[, keep, drop = FALSE], 2, med[keep], "-")
    Z <- sweep(Z, 2, sc[keep], "/")
  } else {
    Z <- scale(X)
  }
  Z[!is.finite(Z)] <- 0

  D <- as.matrix(stats::dist(Z))
  positive_dist <- D[upper.tri(D) & D > 0 & is.finite(D)]

  if (is.null(sigma)) sigma <- stats::median(positive_dist)
  if (!is.finite(sigma) || sigma <= 0) stop("RBF bandwidth sigma is not positive.")

  W <- exp(-(D^2) / (2 * sigma^2))
  diag(W) <- 0

  deg <- rowSums(W)
  deg[deg <= 1e-12] <- 1e-12
  invsqrt <- 1 / sqrt(deg)

  A <- (invsqrt * W) * rep(invsqrt, each = nrow(W))
  A <- (A + t(A)) / 2

  eig <- eigen(A, symmetric = TRUE)
  U <- eig$vectors[, seq_len(k), drop = FALSE]
  nr <- sqrt(rowSums(U^2))
  nr[nr <= 1e-12] <- 1
  U <- U / nr

  set.seed(seed)
  km <- stats::kmeans(U, centers = k, nstart = as.integer(nstart), iter.max = 100)

  list(
    method = "Spectral",
    cluster = as.integer(km$cluster),
    features = X,
    embedding = U,
    affinity = W,
    sigma = sigma,
    model = km,
    k = k,
    lags = lags
  )
}

# =============================================================================
# 5) EMTC wrapper
#
# This calls emtc_eeg_runner.py. The Python helper must be adapted to the
# official EMTC repository version installed on IBEX. No labels are passed.
# =============================================================================

fit_emtc <- function(
    ts,
    emtc_repo,
    python = "python",
    helper_script = "emtc_eeg_runner.py",
    k = 2,
    seed = 123,
    epochs = 200,
    workdir = tempdir()) {

  validate_mts_list(ts)

  mats <- lapply(ts, as.matrix)
  nr <- vapply(mats, nrow, integer(1))
  nc <- vapply(mats, ncol, integer(1))
  if (length(unique(nr)) != 1L) stop("EMTC wrapper currently requires equal-length epochs.")
  if (length(unique(nc)) != 1L) stop("All epochs must have equal channel count.")

  dir.create(workdir, recursive = TRUE, showWarnings = FALSE)

  n <- length(mats)
  Tlen <- nr[1L]
  p <- nc[1L]

  # Flatten each N x T x p epoch into one CSV row; helper reshapes it.
  Xflat <- do.call(rbind, lapply(mats, as.vector))
  input_csv <- file.path(workdir, "emtc_input.csv")
  meta_csv <- file.path(workdir, "emtc_shape.csv")
  output_csv <- file.path(workdir, "emtc_labels.csv")

  utils::write.table(Xflat, input_csv, sep = ",", row.names = FALSE, col.names = FALSE)
  utils::write.table(
    data.frame(N = n, T = Tlen, P = p),
    meta_csv, sep = ",", row.names = FALSE, col.names = TRUE
  )

  cmd_args <- c(
    normalizePath(helper_script, mustWork = TRUE),
    "--repo", normalizePath(emtc_repo, mustWork = TRUE),
    "--input_csv", normalizePath(input_csv, mustWork = TRUE),
    "--shape_csv", normalizePath(meta_csv, mustWork = TRUE),
    "--output", output_csv,
    "--k", as.character(k),
    "--seed", as.character(seed),
    "--epochs", as.character(epochs)
  )

  status <- system2(python, args = shQuote(cmd_args))

  if (!identical(status, 0L)) {
    stop("EMTC Python runner failed with exit status ", status)
  }
  if (!file.exists(output_csv)) stop("EMTC did not create the expected label file.")

  cl <- scan(output_csv, what = integer(), sep = ",", quiet = TRUE)
  if (length(cl) != n) stop("EMTC returned ", length(cl), " labels; expected ", n, ".")

  list(
    method = "EMTC",
    cluster = as.integer(cl),
    k = k,
    seed = seed,
    epochs = epochs
  )
}
