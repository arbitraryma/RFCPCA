# ============================================================
# ROBCPCA: lag 1 + lag 2 combined implementation
# Repository-faithful consolidation of the public code from:
#   algorithm1.R
#   algorithm2.R
#   algorithm3.R -> robcpca_lag_12()
#   standarize_cross covariance.R
#
# Main function to use:
#   robcpca_lag_12(ts, k)
# ============================================================

library(base)
library(stats)
library(r2spss)
library(dvmisc)
library(cellWise)
library(rrcov)
library(pracma)
library(fungible)

# ============================================================
# Algorithm 1: common projection axes
# ============================================================
comaxe <- function(sigma, p = NULL) {
  sigma_com <- 0
  n <- length(sigma)

  for (i in 1:n) {
    sigma_com <- sigma_com + sigma[[i]]
  }

  sigma_com <- (1 / n) * sigma_com

  a <- svd(sigma_com)
  b <- a$d
  c <- a$u

  prop <- b / sum(b)
  cum <- cumsum(prop)
  cumulative_variance <- cum

  if (is.null(p)) {
    p <- which(cumulative_variance >= 0.9)[1]
  } else {
    p <- p
  }

  S <- c[, 1:p, drop = FALSE]

  list(S, p)
}

# ============================================================
# Algorithm 2: robust initial grouping
# ============================================================
initi_label <- function(ts, k) {
  n <- length(ts)

  max_iter <- 100
  mu <- list()
  sigma <- list()

  diff <- Inf
  idealprop <- rep(1 / k, k)
  prop <- rep(0, k)

  t <- ifelse(k <= 5,
              ifelse(k == 2, 0.3, 0.2),
              0.2)

  iter <- 1

  while ((diff > t | any(prop == 0)) && iter < max_iter) {

    a <- sample(n, 1)

    est <- CovMrcd(ts[[a]], alpha = 0.75)
    mu[[1]] <- est@center
    sigma[[1]] <- est@cov

    dist <- matrix(0, n, k)

    for (m in 2:k) {

      dist[, m - 1] <- sapply(1:n, function(i) {
        min(sapply(1:(m - 1), function(j) {
          mean(trim(
            mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
            0.2,
            tails = "upper"
          ))
        }))
      })

      sqdist <- dist[, m - 1]^2
      prob <- sqdist / sum(sqdist)

      next_centroid_idx <- sample(1:n, 1, prob = prob)

      est <- CovMrcd(ts[[next_centroid_idx]], alpha = 0.75)
      mu[[m]] <- est@center
      sigma[[m]] <- est@cov
    }

    dist[, k] <- sapply(1:n, function(i) {
      min(sapply(1:k, function(j) {
        mean(trim(
          mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
          0.2,
          tails = "upper"
        ))
      }))
    })

    assignment <- sapply(1:n, function(i) {
      which.min(sapply(1:k, function(j) {
        mean(trim(
          mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
          0.2,
          tails = "upper"
        ))
      }))
    })

    actual_props <- table(
      factor(assignment, levels = 1:k)
    ) / n

    prop <- as.numeric(actual_props)
    diff <- max(abs(prop - idealprop))
    iter <- iter + 1
  }

  if (iter >= max_iter) {

    while (any(prop == 0)) {

      a <- sample(n, 1)

      est <- CovMrcd(ts[[a]], alpha = 0.75)
      mu[[1]] <- est@center
      sigma[[1]] <- est@cov

      dist <- matrix(0, n, k)

      for (m in 2:k) {

        dist[, m - 1] <- sapply(1:n, function(i) {
          min(sapply(1:(m - 1), function(j) {
            mean(trim(
              mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
              0.2,
              tails = "upper"
            ))
          }))
        })

        sqdist <- dist[, m - 1]^2
        prob <- sqdist / sum(sqdist)

        next_centroid_idx <- sample(1:n, 1, prob = prob)

        est <- CovMrcd(ts[[next_centroid_idx]], alpha = 0.75)
        mu[[m]] <- est@center
        sigma[[m]] <- est@cov
      }

      dist[, k] <- sapply(1:n, function(i) {
        min(sapply(1:k, function(j) {
          mean(trim(
            mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
            0.2,
            tails = "upper"
          ))
        }))
      })

      assignment <- sapply(1:n, function(i) {
        which.min(sapply(1:k, function(j) {
          mean(trim(
            mahalanobis(ts[[i]], mu[[j]], sigma[[j]]),
            0.2,
            tails = "upper"
          ))
        }))
      })

      actual_props <- table(
        factor(assignment, levels = 1:k)
      ) / n

      prop <- as.numeric(actual_props)
    }
  }

  return(assignment)
}

# ============================================================
# Lag utilities
# ============================================================
standardize_mts <- function(mts_data) {
  lapply(mts_data, function(ts) {
    scale(ts, center = TRUE, scale = FALSE)
  })
}

cross_covariance_lag1 <- function(mts_data) {
  n <- nrow(mts_data)
  p <- ncol(mts_data)

  if (n < 2) {
    stop("The multivariate time series should have at least 2 time points.")
  }

  Gamma_0 <- cov(mts_data)

  X_t <- mts_data[1:(n - 1), , drop = FALSE]
  X_t_plus_1 <- mts_data[2:n, , drop = FALSE]

  Gamma_1 <- cov(X_t, X_t_plus_1)

  block_matrix <- rbind(
    cbind(Gamma_0, Gamma_1),
    cbind(t(Gamma_1), Gamma_0)
  )

  output <- list(block_matrix, X_t, X_t_plus_1)
  return(output)
}

cross_covariance_lag2 <- function(mts_data) {
  n <- nrow(mts_data)
  p <- ncol(mts_data)

  if (n < 3) {
    stop("The multivariate time series should have at least 3 time points.")
  }

  Gamma_0 <- cov(mts_data)

  X_t <- mts_data[1:(n - 2), , drop = FALSE]
  X_t_plus_2 <- mts_data[3:n, , drop = FALSE]

  Gamma_2 <- cov(X_t, X_t_plus_2)

  block_matrix <- rbind(
    cbind(Gamma_0, Gamma_2),
    cbind(t(Gamma_2), Gamma_0)
  )

  output <- list(block_matrix, X_t, X_t_plus_2)
  return(output)
}

combine_xt_xt1 <- function(tsxt, tsxt1) {
  combined_matrix <- cbind(tsxt, tsxt1)
  return(combined_matrix)
}

# ============================================================
# Algorithm 3: ROBCPCA with lag 1 + lag 2
# ============================================================
robcpca_lag_12 <- function(ts, k, p = NULL) {

  n <- length(ts)

  # This assignment is in the public repository implementation.
  # It overwrites the input p and the resulting value is not passed
  # to comaxe(), so the common subspace uses the automatic 90% rule.
  p <- ncol(ts[[1]])

  k <- k
  l <- c(rep(1 / k, k))
  dim <- ncol(ts[[1]])

  ts1 <- list()
  sigma <- list()

  # Center each MTS object
  ts1 <- standardize_mts(ts)

  # --------------------
  # Lag 1
  # --------------------
  results <- lapply(ts1, cross_covariance_lag1)

  sigma <- lapply(results, function(x) x[[1]])

  sigma <- lapply(sigma, function(mat) {
    mat + diag(0.01,
               nrow = nrow(mat),
               ncol = ncol(mat))
  })

  tsxt <- lapply(results, function(x) x[[2]])
  tsxt1 <- lapply(results, function(x) x[[3]])

  combined_list <- mapply(
    combine_xt_xt1,
    tsxt,
    tsxt1,
    SIMPLIFY = FALSE
  )

  # --------------------
  # Lag 2
  # --------------------
  results2 <- lapply(ts1, cross_covariance_lag2)

  sigma2 <- lapply(results2, function(x) x[[1]])

  sigma2 <- lapply(sigma2, function(mat) {
    mat + diag(0.01,
               nrow = nrow(mat),
               ncol = ncol(mat))
  })

  tsxt2 <- lapply(results2, function(x) x[[2]])
  tsxt12 <- lapply(results2, function(x) x[[3]])

  combined_list2 <- mapply(
    combine_xt_xt1,
    tsxt2,
    tsxt12,
    SIMPLIFY = FALSE
  )

  # --------------------
  # Robust initialization
  # --------------------
  group <- list()
  group2 <- list()
  s <- list()
  s2 <- list()

  indx <- initi_label(ts, k)

  for (j in 1:k) {
    group[[j]] <- sigma[indx == j]
    s[[j]] <- comaxe(group[[j]])

    group2[[j]] <- sigma2[indx == j]
    s2[[j]] <- comaxe(group2[[j]])
  }

  # --------------------
  # Refinement
  # --------------------
  t <- 0
  tmax <- 100

  toterror <- rep(0, tmax + 1)
  error <- matrix(rep(0, n * k), ncol = k)

  while (t <= tmax) {

    t <- t + 1

    for (m in 1:n) {

      for (ll in 1:k) {

        y1 <- combined_list[[m]] %*%
          s[[ll]][[1]] %*%
          t(s[[ll]][[1]])

        y2 <- combined_list2[[m]] %*%
          s2[[ll]][[1]] %*%
          t(s2[[ll]][[1]])

        df <- normF(combined_list[[m]] - y1) +
              normF(combined_list2[[m]] - y2)

        error[m, ll] <- df
      }
    }

    # Minimum projection error for each MTS
    a <- apply(error, 1, function(x) {
      minerror <- min(x)
    })

    # Cluster corresponding to minimum error
    indx <- apply(error, 1, function(x) {
      cluster_index <- which.min(x)
    })

    toterror[t + 1] <- sum(a)

    if (abs(toterror[t + 1] - toterror[t]) < .Machine$double.eps) {
      break
    }

    # Prevent empty clusters
    while (length(unique(indx)) != k) {
      indx <- sample.int(
        k,
        n,
        replace = TRUE,
        prob = rep(1 / k, k)
      )
    }

    # Update lag-1 and lag-2 common projection spaces
    for (j in 1:k) {

      group[[j]] <- sigma[indx == j]
      s[[j]] <- comaxe(group[[j]])

      group2[[j]] <- sigma2[indx == j]
      s2[[j]] <- comaxe(group2[[j]])
    }
  }

  return(indx)
}

# ============================================================
# Optional simulation wrapper
# Does NOT change the ROBCPCA algorithm; only times it and
# packages its output.
# ============================================================
run_robcpca_lag12 <- function(ts, k, seed = NULL) {

  if (!is.null(seed)) {
    set.seed(seed)
  }

  runtime <- system.time({
    labels <- robcpca_lag_12(ts = ts, k = k)
  })["elapsed"]

  list(
    labels = labels,
    runtime = unname(runtime),
    cluster_sizes = table(labels)
  )
}

# ============================================================
# Example
# ============================================================
# source("ROBCPCA_lag12_repo_faithful.R")
#
# set.seed(123)
# fit <- run_robcpca_lag12(
#   ts = data_list,
#   k = 2,
#   seed = 123
# )
#
# pred_robcpca <- fit$labels
# fit$runtime
# table(pred_robcpca)
#
# # ARI
# # mclust::adjustedRandIndex(true_label, pred_robcpca)
#
# # RI
# # fossil::rand.index(true_label, pred_robcpca)
