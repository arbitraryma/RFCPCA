RFCPCA FINAL SIMULATION — IBEX UPLOAD PACKAGE

This package contains the exact final-simulation driver, worker, method sources,
generator, metric code, baseline implementations, and SLURM script used for the
current run. Preserve the directory layout when extracting it.

UPLOAD AND EXTRACT

  scp rfcpca_ibex_simulation_code.tar.gz ibex-glogin:~/
  ssh ibex-glogin
  mkdir -p ~/RFCPCA_project
  tar -xzf ~/rfcpca_ibex_simulation_code.tar.gz -C ~/RFCPCA_project
  cd ~/RFCPCA_project

REQUIRED R MODULE AND PACKAGES

The run used:

  module purge
  module load rl9-cpustack
  module load R/4.5.0/gnu-12.2.0

See SIMULATION_FREEZE_CONFIG.txt for the audited package versions. The R library
must contain signal, mclust, mlmts, fclust, TSdist, dtwclust, corpcor, Riemann,
rrcov, cellWise, dvmisc, fungible, e1071, and the dependencies they require.

OUTPUT LOCATION

The SLURM script writes to:

  $HOME/RFCPCA_project/final_simulation_2026

Existing valid checkpoint files are resumable. Each method checkpoint is skipped
when a readable output file already exists, so the same task IDs can be submitted
against a copied checkpoint directory without regenerating completed datasets.

SUBMISSION

Ibex rejected a single 2,160-element submitted array under the active QOS limit.
Submit the grid in two halves. Run phase 2 only after phase 1 leaves the queue:

  mkdir -p logs
  sbatch --array=1-1080%20 eeg_revision_benchmark/25_final_simulation_array.sbatch
  sbatch --array=1081-2160%20 eeg_revision_benchmark/25_final_simulation_array.sbatch

Do not submit both halves simultaneously if the QOS submitted-job limit is 2,000.

GRID

  Designs: A, B, C
  p: 32, 64, 128, 256
  T: fixed_200, fixed_400, varying_200_1200
  rho: 0, 0.15, 0.30
  seeds: 1:20
  total scenario tasks: 2,160

Each task creates or reuses one shared dataset and runs the method list in
eeg_revision_benchmark/25_final_simulation_task.R. Each method has a 400-second
worker timeout. SLURM resources are one CPU and 64 GB per task, with 20 concurrent
array tasks.

IMPORTANT

The code preserves the frozen metric rules. RFCPCA-N RI/ARI uses
substantive_hard_cluster, including noise-winning observations through their best
substantive assignment. RFCPCA-T uses posthoc_hard_cluster, including trimmed
observations through their post-hoc substantive assignment.

No simulation is submitted by this package itself.
