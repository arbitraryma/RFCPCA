# Selected baseline implementations used by the reviewer simulations.
# Mc2PCA follows mlmts 1.1.2 (GPL-2) but replaces its TSdist Euclidean call
# with the algebraically identical base-R sum of squared residuals.

mc2_common_space <- function(X, var_rate=.90) {
  S <- Reduce(`+`,lapply(X,stats::cov))/length(X)
  ee <- eigen(S,symmetric=TRUE)
  q <- which(cumsum(pmax(ee$values,0))/sum(pmax(ee$values,0))>=var_rate)[1]
  ee$vectors[,seq_len(max(1L,q)),drop=FALSE]
}

mc2pca_baseline <- function(X,k=2L,var_rate=.90,maxit=150L,tol=1e-5,seed=NULL) {
  if(!is.null(seed)) set.seed(seed)
  X <- lapply(X,function(x)scale(x,scale=FALSE)); n<-length(X)
  lab <- sample(rep(seq_len(k),length.out=n)); old_obj<-Inf
  for(it in seq_len(maxit)) {
    if(length(unique(lab))<k) lab<-sample(rep(seq_len(k),length.out=n))
    axes<-lapply(seq_len(k),function(s)mc2_common_space(X[lab==s],var_rate))
    E<-vapply(X,function(x)vapply(axes,function(A){R<-x-x%*%A%*%t(A);sum(R*R)},numeric(1)),numeric(k))
    newlab<-max.col(-t(E)); obj<-sum(apply(t(E),1,min))
    if(identical(newlab,lab)||abs(old_obj-obj)<tol) {lab<-newlab;break}
    lab<-newlab;old_obj<-obj
  }
  list(cluster=lab,iterations=it,converged=it<maxit)
}

qcd_features_selected <- function(X,levels=c(.1,.5,.9),freq=NULL,...) {
  if(!requireNamespace("quantspec",quietly=TRUE))stop("Package 'quantspec' is required")
  one<-function(Z){
    q<-if(is.null(freq)) quantspec::smoothedPG(Z,levels.1=levels,type="clipped",...) else
      quantspec::smoothedPG(Z,levels.1=levels,type="clipped",frequencies=freq,...)
    fr<-quantspec::getFrequencies(q); v<-quantspec::getValues(q,frequencies=fr)
    c(Re(as.vector(v)),Im(as.vector(v)))
  }
  do.call(rbind,lapply(X,one))
}

modwt_features_selected <- function(X,wf="d4",J=NULL) {
  if(!requireNamespace("waveslim",quietly=TRUE))stop("Package 'waveslim' is required")
  if(is.null(J))J<-max(1L,floor(log2(nrow(X[[1]])))-1L)
  one<-function(Z){
    N<-nrow(Z);K<-ncol(Z); w<-lapply(seq_len(K),function(j)waveslim::modwt(Z[,j],wf,J))
    wb<-lapply(w,waveslim::brick.wall,wf); vv<-lapply(wb,waveslim::wave.variance)
    feat<-t(do.call(cbind,lapply(vv,`[[`,1)))
    if(K>1)for(j in seq_len(K-1L))for(i in (j+1L):K)
      feat<-rbind(feat,waveslim::wave.correlation(wb[[j]],wb[[i]],N)[,1])
    c(feat[,-ncol(feat),drop=FALSE])
  }
  do.call(rbind,lapply(X,one))
}
