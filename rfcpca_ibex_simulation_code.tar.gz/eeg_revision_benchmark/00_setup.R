## Shared configuration for the EEG revision benchmark.
options(stringsAsFactors = FALSE)
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")

BENCHMARK_DIR <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- grep("^--file=", a, value = TRUE)
  if (length(f)) dirname(normalizePath(sub("^--file=", "", f[[1]]), mustWork = FALSE))
  else normalizePath("eeg_revision_benchmark", mustWork = FALSE)
})
PROJECT_DIR <- normalizePath(file.path(BENCHMARK_DIR, ".."), mustWork = TRUE)
RESULTS_DIR <- file.path(BENCHMARK_DIR, "simulation_results")
dir.create(file.path(RESULTS_DIR, "datasets"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS_DIR, "main"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS_DIR, "scalability"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS_DIR, "summaries"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS_DIR, "logs"), recursive = TRUE, showWarnings = FALSE)

K_TRUE <- 2L
N_PER_GROUP <- 20L
FS <- 100L
P_GRID <- c(32L, 64L, 128L, 256L)
RHO_GRID <- c(0, .15, .30)
T_FIXED_GRID <- c(400L, 1000L)
N_REP <- 20L
BASE_SEED <- 20260928L
M_GRID <- c(1.05, 1.1, 1.2, 1.4, 1.6, 1.8, 2.0)
ALPHA_GRID <- c(.10, .20, .30, .40)
CLUSTER1_DOMINANT_BANDS <- c(1L, 2L, 3L, 5L)
CLUSTER2_DOMINANT_BANDS <- c(2L, 4L)
DOMINANT_PROPORTION <- .85
HEAVY_SCALE <- c(1, 2)
VARIANCE_FACTOR <- c(1.5, 3)
METHODS <- c("FCPCA", "RFCPCA-E", "RFCPCA-N", "RFCPCA-T",
             "FuzzCoh", "QCD-E", "QCD-N", "QCD-T",
             "MODWT-E", "MODWT-N", "MODWT-T", "Bandpower-FCM")
TIMEOUT_SEC <- 600

dataset_seed <- function(p_index, rho_index, replication) {
  BASE_SEED + 100000L * p_index + 1000L * rho_index + as.integer(replication)
}

source_local <- function(name) source(file.path(BENCHMARK_DIR, name), local = FALSE)

required_packages <- c("signal", "mclust", "R.utils")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages)) stop("Missing required package(s): ", paste(missing_packages, collapse = ", "))

