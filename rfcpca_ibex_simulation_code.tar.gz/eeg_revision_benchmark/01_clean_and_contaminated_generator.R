## Canonical clean EEG generator refactored from draft code/EEG_simu.R.
## The AR(2), filtering, and coefficient-generation logic is intentionally kept.

extract_rhythms <- function(x, fs, rhythms = c("delta", "theta", "alpha", "beta", "gamma"),
                            method = "butter", twosided = FALSE) {
  limits <- list(delta = c(.5, 4), theta = c(4, 8), alpha = c(8, 12),
                 beta = c(12, 30), gamma = c(30, 45))
  lapply(rhythms, function(r) {
    if (!r %in% names(limits)) stop("Unknown EEG rhythm: ", r)
    co <- if (method == "butter") signal::butter(4, limits[[r]] / (.5 * fs), type = "pass")
          else if (method == "fir") signal::fir1(100, limits[[r]] / (.5 * fs), type = "pass")
          else stop("method must be 'butter' or 'fir'")
    as.numeric(if (twosided) signal::filtfilt(co, x) else signal::filter(co, x))
  })
}

fband.arcoefs <- function(fband, samp.rate = 100) {
  pars <- list(delta = c(2, .03), theta = c(6, .03), alpha = c(10, .03),
               beta = c(22.5, .05), gamma = c(37.5, .075))
  if (!fband %in% names(pars)) stop("Unknown EEG band: ", fband)
  peak <- pars[[fband]][1]; sharpness <- pars[[fband]][2]
  c(exp(-sharpness) * 2 * cos(2 * pi * peak / samp.rate), -exp(-2 * sharpness))
}

gen.coef <- function(idx, p) {
  coeffs <- numeric(5); w1 <- p / length(idx); eps1 <- 1e-1
  for (i in idx) coeffs[i] <- if (i != max(idx)) runif(1, w1 - eps1, w1 + eps1) else
    p - sum(coeffs[idx[-length(idx)]])
  if (p < 1) {
    idxc <- setdiff(1:5, idx); w2 <- (1 - p) / length(idxc); eps2 <- 1e-2
    for (i in idxc) coeffs[i] <- if (i != max(idxc)) runif(1, w2 - eps2, w2 + eps2) else
      1 - p - sum(coeffs[idxc[-length(idxc)]])
  }
  coeffs
}

gen.latent <- function(fband, lenT, samp.rate = 100) {
  phis <- fband.arcoefs(fband, samp.rate)
  z <- as.numeric(arima.sim(lenT, model = list(ar = phis)))
  z <- z - mean(z)
  extract_rhythms(z, fs = samp.rate, rhythms = fband, method = "butter", twosided = TRUE)[[1]]
}

gen.ts <- function(coef, lenT, samp.rate = 100) {
  bands <- c("delta", "theta", "alpha", "beta", "gamma")
  Z <- do.call(cbind, lapply(bands, function(b) as.numeric(scale(gen.latent(b, lenT, samp.rate)))))
  Z %*% coef
}

channel_sd <- function(X) { s <- apply(X, 2, sd); s[!is.finite(s) | s == 0] <- 1; s }

add_heavy_tail <- function(X, scale_range = HEAVY_SCALE) {
  sc <- runif(1, min(scale_range), max(scale_range)); s <- channel_sd(X)
  X + sweep(matrix(rt(length(X), df = 3), nrow(X), ncol(X)), 2, sc * s, "*")
}

add_variance_innovation <- function(X, factor_range = VARIANCE_FACTOR) {
  fac <- runif(1, min(factor_range), max(factor_range)); s <- channel_sd(X)
  X + sweep(matrix(rnorm(length(X)), nrow(X), ncol(X)), 2, fac * s, "*")
}

add_blink <- function(X, fs = FS) {
  frontal <- seq_len(max(1L, ceiling(.25 * ncol(X)))); events <- vector("list", sample(1:2, 1))
  s <- channel_sd(X)
  for (b in seq_along(events)) {
    duration <- sample(round(.2 * fs):round(.4 * fs), 1)
    start <- sample.int(nrow(X) - duration + 1L, 1)
    nch <- max(1L, round(length(frontal) * runif(1, .15, .30)))
    ch <- sample(frontal, min(nch, length(frontal)))
    wave <- sample(c(-1, 1), 1) * sin(seq(0, pi, length.out = duration))
    amp <- runif(length(ch), 4, 8) * s[ch]
    X[start:(start + duration - 1L), ch] <- X[start:(start + duration - 1L), ch, drop = FALSE] + outer(wave, amp)
    events[[b]] <- list(start = start, duration = duration, channels = ch)
  }
  list(X = X, events = events)
}

add_emg <- function(X, fs = FS) {
  events <- vector("list", sample(1:3, 1)); s <- channel_sd(X)
  for (b in seq_along(events)) {
    duration <- sample(round(.2 * fs):round(.3 * fs), 1)
    start <- sample.int(nrow(X) - duration + 1L, 1)
    nch <- max(1L, round(ncol(X) * runif(1, .10, .20))); ch <- sample.int(ncol(X), nch)
    freq <- runif(1, 30, 45); tt <- (0:(duration - 1L)) / fs
    hann <- .5 - .5 * cos(2 * pi * (0:(duration - 1L)) / max(1, duration - 1L))
    wave <- sin(2 * pi * freq * tt + runif(1, 0, 2 * pi)) * hann
    amp <- runif(length(ch), 4, 7) * s[ch]
    X[start:(start + duration - 1L), ch] <- X[start:(start + duration - 1L), ch, drop = FALSE] + outer(wave, amp)
    events[[b]] <- list(start = start, duration = duration, channels = ch, frequency = freq)
  }
  list(X = X, events = events)
}

contamination_plan <- function(rho, labels, profile = c("mixed", "local_only", "global_only")) {
  profile <- match.arg(profile)
  plan <- rep("clean", length(labels))
  if (rho == 0) return(plan)
  for (g in 1:2) {
    ids <- sample(which(labels == g))
    types <- if (abs(rho - .15) < 1e-10) c(if (g == 1) "heavy_tail" else "variance", "blink", "emg")
             else if (abs(rho - .30) < 1e-10) c("heavy_tail", "variance", "blink", "blink", "emg", "emg")
             else stop("rho must be one of 0, .15, .30")
    if (profile == "local_only") types <- rep(c("blink", "emg"), length.out = length(types))
    if (profile == "global_only") types <- rep(c("heavy_tail", "variance"), length.out = length(types))
    plan[ids[seq_along(types)]] <- types
  }
  plan
}

simulate_eeg_dataset <- function(p, rho, seed, lengths = NULL,
                                 dominant_proportion = DOMINANT_PROPORTION,
                                 n_per_group = N_PER_GROUP, fs = FS,
                                 contamination_profile = "mixed",
                                 heavy_scale = HEAVY_SCALE,
                                 variance_factor = VARIANCE_FACTOR,
                                 cluster1_bands = CLUSTER1_DOMINANT_BANDS,
                                 cluster2_bands = CLUSTER2_DOMINANT_BANDS) {
  set.seed(seed)
  labels <- rep(1:2, each = n_per_group); n <- length(labels)
  if (is.null(lengths)) lengths <- sample(400:1200, n, replace = TRUE)
  if (length(lengths) == 1L) lengths <- rep(as.integer(lengths), n)
  stopifnot(length(lengths) == n)
  coef1 <- sapply(seq_len(p), function(j) gen.coef(cluster1_bands, dominant_proportion))
  coef2 <- sapply(seq_len(p), function(j) gen.coef(cluster2_bands, dominant_proportion))
  ts <- lapply(seq_len(n), function(i) gen.ts(if (labels[i] == 1) coef1 else coef2, lengths[i], fs))
  clean_ts <- lapply(ts, function(x) x)
  contam_type <- contamination_plan(rho, labels, contamination_profile); metadata <- vector("list", n)
  for (i in which(contam_type != "clean")) {
    typ <- contam_type[i]
    if (typ == "heavy_tail") ts[[i]] <- add_heavy_tail(ts[[i]], heavy_scale)
    if (typ == "variance") ts[[i]] <- add_variance_innovation(ts[[i]], variance_factor)
    if (typ == "blink") { z <- add_blink(ts[[i]], fs); ts[[i]] <- z$X; metadata[[i]] <- z$events }
    if (typ == "emg") { z <- add_emg(ts[[i]], fs); ts[[i]] <- z$X; metadata[[i]] <- z$events }
  }
  list(ts = ts, clean_ts = clean_ts, labels = labels, T_lengths = as.integer(lengths),
       is_outlier = contam_type != "clean",
       is_global = contam_type %in% c("heavy_tail", "variance"),
       is_local = contam_type %in% c("blink", "emg"), contam_type = contam_type,
       artifact_metadata = metadata, coef1 = coef1, coef2 = coef2,
       true_subspaces = list(cluster1 = t(coef1), cluster2 = t(coef2)),
       config = list(p = p, rho = rho, seed = seed, fs = fs,
                     dominant_proportion = dominant_proportion,
                     cluster1_dominant_bands = cluster1_bands,
                     cluster2_dominant_bands = cluster2_bands,
                     contamination_profile = contamination_profile,
                     heavy_scale = heavy_scale, variance_factor = variance_factor))
}
