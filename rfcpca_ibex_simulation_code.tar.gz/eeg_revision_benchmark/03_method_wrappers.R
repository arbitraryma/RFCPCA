## Existing implementation mapping (verified before wrapper construction):
## method       exact function                    inputs              membership/outlier/subspace
## FCPCA        fcpca_fast                        ts,k,m              membership_matrix / -- / projection_axes
## RFCPCA-E     rfcpca_e_fast_once                ts,k,m              membership_matrix / -- / projection_axes
## RFCPCA-N     rfcpca_n_fast_once                ts,k,m              membership_matrix; valid_membership_matrix / noise_is_winner / projection_axes
## RFCPCA-T     rfcpca_t_fast_once                ts,k,m,alpha        membership_matrix; posthoc_membership_matrix / trim_set / projection_axes
## QCD-*        qcd_features_selected + FCM       equal-length only  U / noise or trim set / --
## MODWT-*      modwt_features_selected + FCM     equal-length only  U / noise or trim set / --
## FuzzCoh      no reusable published simulator wrapper located; TODO: provide validated function/file
## Bandpower    bandpower_features + fuzzy FCM    ts,k,m              U / -- / --

source(file.path(PROJECT_DIR, "New_code", "RFCPCA_revised.R"), local = FALSE)
source(file.path(PROJECT_DIR, "revision_simulation", "baseline_selected.R"), local = FALSE)
`%||%` <- function(x, y) if (is.null(x)) y else x

empty_fit <- function(method, status, msg = NA_character_, runtime = NA_real_) list(
  method = method, membership = NULL, regular_membership = NULL,
  predicted_cluster = NULL, predicted_outlier = NULL, selected_m = NA_real_,
  selected_alpha = NA_real_, fitted_subspaces = NULL, iterations = NA_integer_,
  converged = NA, runtime_sec = runtime, status = status, error_message = msg)

select_cvi <- function(fits) {
  score <- vapply(fits, function(z) if (inherits(z, "candidate_error")) Inf else z$S_value %||% Inf, numeric(1))
  ok <- which(is.finite(score)); if (!length(ok)) stop("No candidate produced a finite within-method CVI")
  fits[[ok[which.min(score[ok])]]]
}

safe_candidate <- function(expr) tryCatch(expr, error = function(e) structure(
  list(error_message = conditionMessage(e)), class = "candidate_error"))

wrap_rfcpca_family <- function(method, ts, seed) {
  prep <- prepare_fcpca_data(ts)
  if (method == "FCPCA") fits <- lapply(seq_along(M_GRID), function(i) safe_candidate(
    fcpca_fast(ts, K_TRUE, M_GRID[i], prep = prep, verbose = FALSE,
               seed = seed + i, maxit = 50, replicates = 1, init_method = "robust_lag")))
  if (method == "RFCPCA-E") fits <- lapply(seq_along(M_GRID), function(i)
    safe_candidate(rfcpca_e_fast_once(ts, K_TRUE, M_GRID[i], prep = prep, verbose = FALSE,
                       seed = seed + i, maxit = 50, init_method = "robust_lag")))
  if (method == "RFCPCA-N") fits <- lapply(seq_along(M_GRID), function(i)
    safe_candidate(rfcpca_n_fast_once(ts, K_TRUE, M_GRID[i], prep = prep, verbose = FALSE,
                       seed = seed + i, maxit = 50, init_method = "robust_lag")))
  if (method == "RFCPCA-T") fits <- unlist(lapply(seq_along(M_GRID), function(i)
    lapply(seq_along(ALPHA_GRID), function(j) safe_candidate(rfcpca_t_fast_once(
      ts, K_TRUE, M_GRID[i], ALPHA_GRID[j], prep = prep, verbose = FALSE,
      seed = seed + 10L * i + j, maxit = 50, init_method = "robust_lag")))), recursive = FALSE)
  z <- select_cvi(fits)
  U <- z$membership_matrix; regular <- U
  pred_out <- NULL; pred <- z$hard_cluster
  if (method == "RFCPCA-N") {
    regular <- z$valid_membership_matrix; regular <- regular / pmax(rowSums(regular), .Machine$double.eps)
    pred <- z$substantive_hard_cluster; pred_out <- z$noise_is_winner
  }
  if (method == "RFCPCA-T") {
    regular <- z$posthoc_membership_matrix; pred <- z$posthoc_hard_cluster; pred_out <- z$trim_set
  }
  list(method = method, membership = U, regular_membership = regular,
       predicted_cluster = pred, predicted_outlier = pred_out,
       selected_m = z$m, selected_alpha = z$alpha %||% NA_real_,
       fitted_subspaces = z$projection_axes, iterations = z$iterations,
       converged = z$converged, status = "ok", error_message = NA_character_)
}

run_method_wrapper <- function(method, dat, seed, timeout_sec = TIMEOUT_SEC) {
  unequal <- length(unique(dat$T_lengths)) > 1L
  if (unequal && method %in% c("FuzzCoh", grep("^(QCD|MODWT)", METHODS, value = TRUE)))
    return(empty_fit(method, "NA_unequal_length", "available implementation requires equal-length input"))
  if (method == "FuzzCoh") return(empty_fit(method, "error", "TODO: validated reusable FuzzCoh simulation function/file is needed"))
  if (!method %in% c("FCPCA", "RFCPCA-E", "RFCPCA-N", "RFCPCA-T"))
    return(empty_fit(method, "error", "TODO: feature-family E/N/T wrapper requires validation against the published implementation"))
  started <- proc.time()[[3]]
  ans <- tryCatch(R.utils::withTimeout(wrap_rfcpca_family(method, dat$ts, seed), timeout = timeout_sec,
                                       onTimeout = "error"),
                  TimeoutException = function(e) empty_fit(method, "timeout", conditionMessage(e)),
                  error = function(e) empty_fit(method, "error", conditionMessage(e)))
  ans$runtime_sec <- unname(proc.time()[[3]] - started)
  ans
}
