adjusted_rand <- function(truth, pred) {
  ok <- is.finite(truth) & is.finite(pred)
  if (sum(ok) < 2L) return(NA_real_)
  as.numeric(mclust::adjustedRandIndex(truth[ok], pred[ok]))
}

fuzzy_rand <- function(truth, U) {
  if (is.null(U) || nrow(U) != length(truth)) return(NA_real_)
  U <- U / pmax(rowSums(U), .Machine$double.eps)
  if (requireNamespace("fclust", quietly = TRUE))
    return(as.numeric(fclust::RI.F(VC = truth, U = U))[1])
  ## Hullermeier-style fallback; retained only if fclust is unavailable.
  pairs <- utils::combn(seq_along(truth), 2)
  fuzzy_eq <- 1 - apply(abs(U[pairs[1, ], , drop = FALSE] - U[pairs[2, ], , drop = FALSE]), 1, max)
  crisp_eq <- as.numeric(truth[pairs[1, ]] == truth[pairs[2, ]])
  1 - mean(abs(fuzzy_eq - crisp_eq))
}

anomaly_metrics <- function(pred, dat) {
  if (is.null(pred)) return(c(precision = NA, recall = NA, recall_global = NA, recall_local = NA))
  pred <- as.logical(pred); truth <- dat$is_outlier
  tp <- sum(pred & truth); precision <- if (sum(pred) == 0) NA_real_ else tp / sum(pred)
  recall <- if (!any(truth)) NA_real_ else tp / sum(truth)
  rg <- if (!any(dat$is_global)) NA_real_ else sum(pred & dat$is_global) / sum(dat$is_global)
  rl <- if (!any(dat$is_local)) NA_real_ else sum(pred & dat$is_local) / sum(dat$is_local)
  c(precision = precision, recall = recall, recall_global = rg, recall_local = rl)
}

orth_basis <- function(A, tol = 1e-9) {
  s <- svd(A); r <- sum(s$d > tol * max(s$d, 1)); if (!r) return(matrix(0, nrow(A), 0))
  s$u[, seq_len(r), drop = FALSE]
}

true_lag_basis <- function(A) {
  ## combined1/combined2 are [X_t, X_{t+lag}] in R^(2p).  Thus the compatible
  ## true lagged channel subspace is blockdiag(col(A), col(A)), not A itself.
  Q <- orth_basis(A); p <- nrow(Q); q <- ncol(Q)
  B <- matrix(0, 2L * p, 2L * q); B[seq_len(p), seq_len(q)] <- Q
  B[p + seq_len(p), q + seq_len(q)] <- Q
  B
}

subspace_pair_error <- function(E, Q) {
  E <- orth_basis(E); Q <- orth_basis(Q); r <- max(ncol(E), ncol(Q))
  if (!r) return(0)
  d <- pmin(1, svd(crossprod(E, Q), nu = 0, nv = 0)$d)
  sinsq <- c(1 - d^2, rep(1, r - length(d)))
  sqrt(mean(pmax(0, sinsq)))
}

subspace_error <- function(axes, true_subspaces) {
  if (is.null(axes) || length(axes) != 2L) return(NA_real_)
  Q <- lapply(true_subspaces, true_lag_basis)
  cost <- function(map) mean(vapply(1:2, function(j) {
    e1 <- subspace_pair_error(axes[[j]]$lag01, Q[[map[j]]])
    e2 <- subspace_pair_error(axes[[j]]$lag02, Q[[map[j]]])
    sqrt((e1^2 + e2^2) / 2)
  }, numeric(1)))
  min(cost(c(1, 2)), cost(c(2, 1)))
}

evaluate_method <- function(fit, dat) {
  if (!identical(fit$status, "ok")) return(data.frame(
    ARI_all = NA, ARI_clean = NA, RI_F = NA, precision = NA, recall = NA,
    recall_global = NA, recall_local = NA, subspace_error = NA))
  clean <- dat$contam_type == "clean"; am <- anomaly_metrics(fit$predicted_outlier, dat)
  data.frame(ARI_all = adjusted_rand(dat$labels, fit$predicted_cluster),
             ARI_clean = adjusted_rand(dat$labels[clean], fit$predicted_cluster[clean]),
             RI_F = fuzzy_rand(dat$labels, fit$regular_membership),
             precision = unname(am["precision"]), recall = unname(am["recall"]),
             recall_global = unname(am["recall_global"]), recall_local = unname(am["recall_local"]),
             subspace_error = subspace_error(fit$fitted_subspaces, dat$true_subspaces))
}

