#!/usr/bin/env Rscript
root <- Sys.getenv("FINAL_SIM_OUT", "final_simulation_2026")
files <- Sys.glob(file.path(root, "raw", "*.rds"))
if (!length(files)) stop("no raw results")
rows <- lapply(files, function(f) {
  x <- tryCatch(readRDS(f), error = function(e) NULL)
  if (is.null(x) || is.null(x$row)) return(NULL)
  x$row
})
rows <- Filter(Negate(is.null), rows)
all_names <- unique(unlist(lapply(rows, names)))
rows <- lapply(rows, function(x) {
  for (n in setdiff(all_names, names(x))) x[[n]] <- NA
  x[, all_names, drop = FALSE]
})
raw <- do.call(rbind, rows)
write.csv(raw, file.path(root, "simulation_raw_results.csv"), row.names = FALSE)

finite_summary <- function(x) {
  x <- suppressWarnings(as.numeric(x)); x <- x[is.finite(x)]
  if (!length(x)) return(c(mean = NA, sd = NA, n = 0))
  c(mean = mean(x), sd = if (length(x) > 1) sd(x) else NA, n = length(x))
}
summarize <- function(cols, by, file) {
  cols <- intersect(cols, names(raw))
  key <- interaction(raw[, by, drop = FALSE], drop = TRUE, lex.order = TRUE)
  out <- lapply(split(seq_len(nrow(raw)), key), function(ii) {
    z <- raw[ii[1], by, drop = FALSE]
    for (v in cols) {
      a <- finite_summary(raw[[v]][ii])
      z[[paste0(v, "_mean")]] <- unname(a["mean"])
      z[[paste0(v, "_sd")]] <- unname(a["sd"])
      z[[paste0(v, "_n")]] <- unname(a["n"])
    }
    z
  })
  write.csv(do.call(rbind, out), file.path(root, file), row.names = FALSE)
}

by <- c("method", "design", "p", "length_setting", "rho")
summarize(c("RI_all", "ARI_all", "RI_clean", "ARI_clean", "RI_F"), by,
          "simulation_clustering_summary.csv")
summarize(c("precision", "recall", "F1", "false_positive_rate", "specificity",
            "retained_fraction"), by, "simulation_detection_summary.csv")
summarize(c("clean_influence_mean", "clean_influence_sd", "clean_influence_median",
            "contam_influence_mean", "contam_influence_sd", "contam_influence_median",
            "anomaly_ROC_AUC", "anomaly_PR_AUC"), by,
          "simulation_E_influence_summary.csv")
summarize(c("principal_angle_mean", "principal_angle_max", "projection_error"), by,
          "simulation_subspace_summary.csv")

runtime_by <- c("method", "p", "length_setting", "rho")
key <- interaction(raw[, runtime_by, drop = FALSE], drop = TRUE, lex.order = TRUE)
runtime <- lapply(split(seq_len(nrow(raw)), key), function(ii) {
  z <- raw[ii[1], runtime_by, drop = FALSE]
  x <- suppressWarnings(as.numeric(raw$runtime_sec[ii])); x <- x[is.finite(x)]
  ok <- raw$status[ii] == "OK"
  z$n_attempted <- length(ii); z$n_success <- sum(ok, na.rm = TRUE)
  z$n_timeout <- sum(raw$status[ii] == "TIMEOUT_400", na.rm = TRUE)
  z$timeout_rate <- mean(raw$status[ii] == "TIMEOUT_400", na.rm = TRUE)
  z$convergence_rate <- mean(raw$converged[ii] %in% TRUE, na.rm = TRUE)
  z$runtime_mean <- if (length(x)) mean(x) else NA
  z$runtime_sd <- if (length(x) > 1) sd(x) else NA
  z$runtime_median <- if (length(x)) median(x) else NA
  z$runtime_IQR <- if (length(x)) IQR(x) else NA
  z$runtime_q25 <- if (length(x)) unname(quantile(x, .25)) else NA
  z$runtime_q75 <- if (length(x)) unname(quantile(x, .75)) else NA
  y <- suppressWarnings(as.numeric(raw$runtime_sec[ii][ok])); y <- y[is.finite(y)]
  z$runtime_se_success <- if (length(y) > 1) sd(y) / sqrt(length(y)) else NA
  z
})
runtime <- do.call(rbind, runtime)
write.csv(runtime, file.path(root, "simulation_runtime_summary.csv"), row.names = FALSE)
write.csv(runtime, file.path(root, "runtime_plot_data.csv"), row.names = FALSE)
status <- as.data.frame(xtabs(~ method + status, raw))
write.csv(status[status$Freq > 0, , drop = FALSE],
          file.path(root, "simulation_status_summary.csv"), row.names = FALSE)
cat("aggregated", nrow(raw), "rows from", length(files), "files\n")
